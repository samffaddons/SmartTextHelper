// Settings page functionality

// Immediate console check
console.log('[Settings] Script loaded');
console.log('[Settings] typeof browser:', typeof browser);
console.log('[Settings] typeof chrome:', typeof chrome);

// Use browser API for Firefox
const browserStorageAPI = (typeof browser !== 'undefined' && browser.storage) ? browser : 
                          (typeof chrome !== 'undefined' && chrome.storage) ? chrome : null;

console.log('[Settings] Browser storage API:', browserStorageAPI);

// Storage wrapper that uses localStorage as fallback
const storage = {
  get: function(keys) {
    return new Promise((resolve, reject) => {
      try {
        if (browserStorageAPI && browserStorageAPI.storage && browserStorageAPI.storage.sync) {
          console.log('[Settings] Using browser.storage.sync');
          browserStorageAPI.storage.sync.get(keys).then(resolve).catch((error) => {
            console.warn('[Settings] browser.storage failed, falling back to localStorage:', error);
            this._getFromLocalStorage(keys).then(resolve).catch(reject);
          });
        } else {
          console.log('[Settings] Using localStorage fallback');
          this._getFromLocalStorage(keys).then(resolve).catch(reject);
        }
      } catch (error) {
        console.warn('[Settings] Exception, using localStorage:', error);
        this._getFromLocalStorage(keys).then(resolve).catch(reject);
      }
    });
  },
  
  set: function(items) {
    return new Promise((resolve, reject) => {
      try {
        if (browserStorageAPI && browserStorageAPI.storage && browserStorageAPI.storage.sync) {
          console.log('[Settings] Using browser.storage.sync for save');
          browserStorageAPI.storage.sync.set(items).then(resolve).catch((error) => {
            console.warn('[Settings] browser.storage.set failed, falling back to localStorage:', error);
            this._setToLocalStorage(items).then(resolve).catch(reject);
          });
        } else {
          console.log('[Settings] Using localStorage fallback for save');
          this._setToLocalStorage(items).then(resolve).catch(reject);
        }
      } catch (error) {
        console.warn('[Settings] Exception, using localStorage:', error);
        this._setToLocalStorage(items).then(resolve).catch(reject);
      }
    });
  },
  
  _getFromLocalStorage: function(keys) {
    return new Promise((resolve) => {
      const result = {};
      const keyArray = Array.isArray(keys) ? keys : (keys === null ? ['popupPosition', 'enableHyperlink'] : [keys]);
      
      keyArray.forEach(key => {
        const value = localStorage.getItem('smartTextHelper_' + key);
        if (value !== null) {
          try {
            result[key] = JSON.parse(value);
          } catch (e) {
            result[key] = value;
          }
        }
      });
      
      console.log('[Settings] Retrieved from localStorage:', result);
      resolve(result);
    });
  },
  
  _setToLocalStorage: function(items) {
    return new Promise((resolve) => {
      Object.keys(items).forEach(key => {
        localStorage.setItem('smartTextHelper_' + key, JSON.stringify(items[key]));
      });
      console.log('[Settings] Saved to localStorage:', items);
      resolve();
    });
  }
};

// Load saved settings
function loadSettings() {
  console.log('[Settings] loadSettings() called');
  
  storage.get(['popupPosition', 'enableHyperlink', 'customCities', 'autoCopy', 'autoCopyUnique', 'removeHyperlink', 'enableUSA', 'enableEurope', 'regionHotkey']).then((result) => {
    const position = result.popupPosition || 'top';
    const enableHyperlink = result.enableHyperlink !== undefined ? result.enableHyperlink : true;
    const customCities = result.customCities || {};
    const autoCopy = result.autoCopy || false;
    const autoCopyUnique = result.autoCopyUnique || false;
    const removeHyperlink = result.removeHyperlink || false;
    const enableUSA = result.enableUSA !== undefined ? result.enableUSA : true;
    const enableEurope = result.enableEurope !== undefined ? result.enableEurope : true;
    const regionHotkey = result.regionHotkey || 'Alt+R';
    
    console.log('[Settings] Loading settings:', { position, enableHyperlink, customCities, autoCopy, autoCopyUnique, removeHyperlink, enableUSA, enableEurope, regionHotkey });
    
    // Check the appropriate radio button
    const radio = document.querySelector(`input[value="${position}"]`);
    if (radio) {
      radio.checked = true;
      updateSelectedOption(position);
    }
    
    // Set checkboxes
    const checkbox = document.getElementById('enableHyperlink');
    if (checkbox) {
      checkbox.checked = enableHyperlink;
      console.log('[Settings] Hyperlink checkbox set to:', checkbox.checked);
    }
    
    const autoCopyCheckbox = document.getElementById('autoCopy');
    if (autoCopyCheckbox) {
      autoCopyCheckbox.checked = autoCopy;
      console.log('[Settings] Auto-copy checkbox set to:', autoCopyCheckbox.checked);
    }
    
    const autoCopyUniqueCheckbox = document.getElementById('autoCopyUnique');
    if (autoCopyUniqueCheckbox) {
      autoCopyUniqueCheckbox.checked = autoCopyUnique;
      console.log('[Settings] Auto-copy unique checkbox set to:', autoCopyUniqueCheckbox.checked);
    }
    
    const removeHyperlinkCheckbox = document.getElementById('removeHyperlink');
    if (removeHyperlinkCheckbox) {
      removeHyperlinkCheckbox.checked = removeHyperlink;
      console.log('[Settings] Remove hyperlink checkbox set to:', removeHyperlinkCheckbox.checked);
    }
    
    const enableUSACheckbox = document.getElementById('enableUSA');
    if (enableUSACheckbox) {
      enableUSACheckbox.checked = enableUSA;
      console.log('[Settings] Enable USA checkbox set to:', enableUSACheckbox.checked);
    }
    
    const enableEuropeCheckbox = document.getElementById('enableEurope');
    if (enableEuropeCheckbox) {
      enableEuropeCheckbox.checked = enableEurope;
      console.log('[Settings] Enable Europe checkbox set to:', enableEuropeCheckbox.checked);
    }
    
    const regionHotkeyInput = document.getElementById('regionHotkey');
    if (regionHotkeyInput) {
      regionHotkeyInput.value = regionHotkey;
      document.getElementById('currentHotkey').textContent = regionHotkey;
      console.log('[Settings] Region hotkey set to:', regionHotkey);
    }
    
    // Load custom cities into textarea
    const customCitiesTextarea = document.getElementById('customCities');
    if (customCitiesTextarea) {
      const customCitiesText = Object.entries(customCities)
        .map(([city, location]) => `${city}|${location}`)
        .join('\n');
      customCitiesTextarea.value = customCitiesText;
      console.log('[Settings] Custom cities loaded:', customCitiesText);
    }
  }).catch((error) => {
    console.error('[Settings] Load error:', error);
    alert('ERROR loading settings: ' + error.message);
  });
}

// Update visual selection
function updateSelectedOption(value) {
  document.querySelectorAll('.radio-option').forEach(option => {
    option.classList.remove('selected');
    if (option.dataset.value === value) {
      option.classList.add('selected');
    }
  });
}

// Save settings
function saveSettings() {
  console.log('[Settings] ========== SAVE BUTTON CLICKED ==========');
  
  try {
    const selectedPosition = document.querySelector('input[name="position"]:checked');
    const checkbox = document.getElementById('enableHyperlink');
    const customCitiesTextarea = document.getElementById('customCities');
    
    console.log('[Settings] Selected position element:', selectedPosition);
    console.log('[Settings] Checkbox element:', checkbox);
    console.log('[Settings] Custom cities textarea:', customCitiesTextarea);
    
    if (!selectedPosition) {
      console.error('[Settings] No position selected');
      alert('ERROR: No position radio button is selected. Please select a position.');
      return;
    }
    
    if (!checkbox) {
      console.error('[Settings] Checkbox not found');
      alert('ERROR: Checkbox element not found');
      return;
    }
    
    const position = selectedPosition.value;
    const enableHyperlink = checkbox.checked;
    const autoCopy = document.getElementById('autoCopy')?.checked || false;
    const autoCopyUnique = document.getElementById('autoCopyUnique')?.checked || false;
    const removeHyperlink = document.getElementById('removeHyperlink')?.checked || false;
    const enableUSA = document.getElementById('enableUSA')?.checked !== undefined ? document.getElementById('enableUSA').checked : true;
    const enableEurope = document.getElementById('enableEurope')?.checked !== undefined ? document.getElementById('enableEurope').checked : true;
    const regionHotkey = document.getElementById('regionHotkey')?.value || 'Alt+R';
    
    // Parse custom cities
    const customCities = {};
    if (customCitiesTextarea && customCitiesTextarea.value.trim()) {
      const lines = customCitiesTextarea.value.split('\n');
      lines.forEach((line, index) => {
        line = line.trim();
        if (line && line.includes('|')) {
          const [cityName, location] = line.split('|').map(s => s.trim());
          if (cityName && location) {
            // Store in lowercase for matching
            customCities[cityName.toLowerCase()] = location;
          } else {
            console.warn(`[Settings] Invalid custom city format on line ${index + 1}: ${line}`);
          }
        }
      });
    }
    
    console.log('[Settings] Position:', position);
    console.log('[Settings] enableHyperlink:', enableHyperlink);
    console.log('[Settings] Custom cities:', customCities);
    
    const settingsToSave = {
      popupPosition: position,
      enableHyperlink: enableHyperlink,
      customCities: customCities,
      autoCopy: autoCopy,
      autoCopyUnique: autoCopyUnique,
      removeHyperlink: removeHyperlink,
      enableUSA: enableUSA,
      enableEurope: enableEurope,
      regionHotkey: regionHotkey
    };
    
    console.log('[Settings] Saving:', settingsToSave);
    
    storage.set(settingsToSave).then(() => {
      console.log('[Settings] ✓ Save successful');
      
      // Verify
      storage.get(['popupPosition', 'enableHyperlink', 'customCities', 'autoCopy', 'autoCopyUnique', 'removeHyperlink']).then((result) => {
        console.log('[Settings] ✓ Verified:', result);
        
        const customCityCount = Object.keys(customCities).length;
        
        if (result.enableHyperlink === enableHyperlink && result.popupPosition === position) {
          console.log('[Settings] ✓✓ VERIFICATION SUCCESS');
          alert(`✓ SUCCESS!\n\nSettings saved:\n\nPopup Position: ${position}\nConvert to Link: ${enableHyperlink ? 'ENABLED ✓' : 'DISABLED ✗'}\nRemove Hyperlink: ${removeHyperlink ? 'ENABLED ✓' : 'DISABLED ✗'}\nAuto-Copy All: ${autoCopy ? 'ENABLED ✓' : 'DISABLED ✗'}\nAuto-Copy Unique: ${autoCopyUnique ? 'ENABLED ✓' : 'DISABLED ✗'}\nCustom Cities: ${customCityCount}`);
          showAlert('Success!', `Settings saved successfully!`, 'success');
        } else {
          console.error('[Settings] Verification mismatch');
          alert('WARNING: Settings saved but verification shows different values');
        }
      });
      
    }).catch((error) => {
      console.error('[Settings] Save error:', error);
      alert('ERROR saving: ' + error.message);
    });
    
  } catch (error) {
    console.error('[Settings] Exception:', error);
    alert('EXCEPTION: ' + error.message);
  }
}

// Show alert box
function showAlert(title, message, type = 'success') {
  // Remove existing alerts
  const existingAlerts = document.querySelectorAll('.alert-box');
  existingAlerts.forEach(alert => alert.remove());
  
  // Create new alert
  const alertBox = document.createElement('div');
  alertBox.className = `alert-box ${type}`;
  
  const alertTitle = document.createElement('div');
  alertTitle.className = 'alert-title';
  alertTitle.textContent = title;
  
  const alertMessage = document.createElement('div');
  alertMessage.className = 'alert-message';
  alertMessage.textContent = message;
  
  alertBox.appendChild(alertTitle);
  alertBox.appendChild(alertMessage);
  
  document.body.appendChild(alertBox);
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    alertBox.style.opacity = '0';
    alertBox.style.transform = 'translateX(100px)';
    setTimeout(() => alertBox.remove(), 300);
  }, 5000);
}

// Export settings
function exportSettings() {
  console.log('[Settings] Export button clicked');
  
  storage.get(null).then((settings) => {
    console.log('[Settings] Settings retrieved:', settings);
    
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'smart-text-helper-settings.json';
    link.click();
    
    URL.revokeObjectURL(url);
    
    console.log('[Settings] Export completed');
    alert('✓ Settings exported successfully!');
    showMessage('✓ Settings exported!', 'success');
  }).catch((error) => {
    console.error('[Settings] Export error:', error);
    alert('ERROR exporting: ' + error.message);
  });
}

// Import settings
function importSettings() {
  document.getElementById('importFile').click();
}

function handleFileImport(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const settings = JSON.parse(e.target.result);
      storage.set(settings).then(() => {
        loadSettings();
        alert('✓ Settings imported successfully!');
        showMessage('✓ Settings imported!', 'success');
      });
    } catch (error) {
      alert('ERROR: Invalid settings file');
      showMessage('✗ Invalid file', 'error');
    }
  };
  reader.readAsText(file);
  
  event.target.value = '';
}

function showMessage(text, type) {
  showAlert(type === 'success' ? 'Success' : 'Error', text, type);
  
  // Also update inline message
  const statusMessage = document.getElementById('statusMessage');
  statusMessage.textContent = text;
  statusMessage.className = `status-message ${type}`;
  statusMessage.style.display = 'block';
  
  setTimeout(() => {
    statusMessage.style.display = 'none';
  }, 3000);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
  console.log('[Settings] DOM Content Loaded');
  console.log('[Settings] Initializing event listeners...');
  
  loadSettings();
  
  // Save button
  const saveBtn = document.getElementById('saveBtn');
  console.log('[Settings] Save button element:', saveBtn);
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      console.log('[Settings] Save button clicked (via event listener)');
      saveSettings();
    });
  } else {
    console.error('[Settings] Save button not found!');
  }
  
  // Export button
  const exportBtn = document.getElementById('exportBtn');
  console.log('[Settings] Export button element:', exportBtn);
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      console.log('[Settings] Export button clicked');
      exportSettings();
    });
  }
  
  // Import button
  const importBtn = document.getElementById('importBtn');
  if (importBtn) {
    importBtn.addEventListener('click', importSettings);
  }
  
  const importFile = document.getElementById('importFile');
  if (importFile) {
    importFile.addEventListener('change', handleFileImport);
  }
  
  // Radio button changes
  document.querySelectorAll('input[name="position"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      updateSelectedOption(e.target.value);
    });
  });
  
  // Click on label to select radio
  document.querySelectorAll('.radio-option').forEach(option => {
    option.addEventListener('click', (e) => {
      // Only handle if not clicking the input directly
      if (e.target.tagName !== 'INPUT') {
        const radio = option.querySelector('input[type="radio"]');
        radio.checked = true;
        updateSelectedOption(option.dataset.value);
      }
    });
  });
  
  console.log('[Settings] Event listeners initialized');
});
