// Comprehensive city database for USA and Europe
// Optimized for performance with minimal CPU usage

// This database uses state abbreviations as values for quick lookup
const US_STATE_MAP = {
  "AL": "AL", "AK": "AK", "AZ": "AZ", "AR": "AR", "CA": "CA",
  "CO": "CO", "CT": "CT", "DE": "DE", "FL": "FL", "GA": "GA",
  "HI": "HI", "ID": "ID", "IL": "IL", "IN": "IN", "IA": "IA",
  "KS": "KS", "KY": "KY", "LA": "LA", "ME": "ME", "MD": "MD",
  "MA": "MA", "MI": "MI", "MN": "MN", "MS": "MS", "MO": "MO",
  "MT": "MT", "NE": "NE", "NV": "NV", "NH": "NH", "NJ": "NJ",
  "NM": "NM", "NY": "NY", "NC": "NC", "ND": "ND", "OH": "OH",
  "OK": "OK", "OR": "OR", "PA": "PA", "RI": "RI", "SC": "SC",
  "SD": "SD", "TN": "TN", "TX": "TX", "UT": "UT", "VT": "VT",
  "VA": "VA", "WA": "WA", "WV": "WV", "WI": "WI", "WY": "WY",
  "DC": "DC", "PR": "PR", "VI": "VI", "GU": "GU", "AS": "AS", "MP": "MP"
};

const CITY_DATABASE = {
  // USA Cities - Comprehensive list
  usa: {
    // Major cities first
    "new york": ["NY"], "new york city": ["NY"], "los angeles": ["CA"], "chicago": ["IL"], "houston": ["TX"],
    "phoenix": ["AZ"], "philadelphia": ["PA"], "san antonio": ["TX"], "san diego": ["CA"],
    "dallas": ["TX"], "san jose": ["CA"], "austin": ["TX"], "jacksonville": ["FL"],
    "fort worth": ["TX"], "columbus": ["OH"], "charlotte": ["NC"], "san francisco": ["CA"],
    "indianapolis": ["IN"], "seattle": ["WA"], "denver": ["CO"], "boston": ["MA"],
    
    // California cities
    "poway": ["CA"], "escondido": ["CA"], "carlsbad": ["CA"], "oceanside": ["CA"],
    "vista": ["CA"], "san marcos": ["CA"], "encinitas": ["CA"], "solana beach": ["CA"],
    "del mar": ["CA"], "la jolla": ["CA"], "chula vista": ["CA"], "national city": ["CA"],
    "imperial beach": ["CA"], "coronado": ["CA"], "el cajon": ["CA"], "santee": ["CA"],
    "la mesa": ["CA"], "lemon grove": ["CA"], "spring valley": ["CA"], "jamul": ["CA"],
    "alpine": ["CA"], "ramona": ["CA"], "julian": ["CA"], "borrego springs": ["CA"],
    "sacramento": ["CA"], "fresno": ["CA"], "long beach": ["CA"], "oakland": ["CA"],
    "bakersfield": ["CA"], "anaheim": ["CA"], "santa ana": ["CA"], "riverside": ["CA"],
    "stockton": ["CA"], "irvine": ["CA"], "chula vista": ["CA"], "fremont": ["CA"],
    "san bernardino": ["CA"], "modesto": ["CA"], "fontana": ["CA"], "oxnard": ["CA"],
    "moreno valley": ["CA"], "huntington beach": ["CA"], "glendale": ["CA"], "santa clarita": ["CA"],
    "garden grove": ["CA"], "santa rosa": ["CA"], "oceanside": ["CA"], "rancho cucamonga": ["CA"],
    "ontario": ["CA"], "lancaster": ["CA"], "elk grove": ["CA"], "corona": ["CA"],
    "palmdale": ["CA"], "salinas": ["CA"], "pomona": ["CA"], "hayward": ["CA"],
    "sunnyvale": ["CA"], "pasadena": ["CA"], "torrance": ["CA"], "orange": ["CA"],
    "fullerton": ["CA"], "roseville": ["CA"], "visalia": ["CA"], "concord": ["CA"],
    "thousand oaks": ["CA"], "simi valley": ["CA"], "santa clara": ["CA"], "vallejo": ["CA"],
    "berkeley": ["CA"], "el monte": ["CA"], "downey": ["CA"], "costa mesa": ["CA"],
    "inglewood": ["CA"], "carlsbad": ["CA"], "san buenaventura": ["CA"], "fairfield": ["CA"],
    "west covina": ["CA"], "murrieta": ["CA"], "norwalk": ["CA"], "richmond": ["CA"],
    "burbank": ["CA"], "daly city": ["CA"], "rialto": ["CA"], "santa maria": ["CA"],
    "el cajon": ["CA"], "san mateo": ["CA"], "clovis": ["CA"], "compton": ["CA"],
    "jurupa valley": ["CA"], "vista": ["CA"], "south gate": ["CA"], "mission viejo": ["CA"],
    "vacaville": ["CA"], "carson": ["CA"], "hesperia": ["CA"], "santa monica": ["CA"],
    "westminster": ["CA"], "redding": ["CA"], "santa barbara": ["CA"], "chico": ["CA"],
    "newport beach": ["CA"], "san leandro": ["CA"], "san marcos": ["CA"], "whittier": ["CA"],
    "rancho palos verdes": ["CA"], "palm springs": ["CA"],
    "hawthorne": ["CA"], "citrus heights": ["CA"], "alhambra": ["CA"], "tracy": ["CA"],
    "livermore": ["CA"], "buena park": ["CA"], "lakewood": ["CA"], "merced": ["CA"],
    "hemet": ["CA"], "chino": ["CA"], "menifee": ["CA"], "indio": ["CA"],
    "alameda": ["CA"], "redwood city": ["CA"], "lake forest": ["CA"], "napa": ["CA"],
    "redlands": ["CA"], "folsom": ["CA"], "san ramon": ["CA"], "temecula": ["CA"],
    "turlock": ["CA"], "manteca": ["CA"], "tustin": ["CA"], "palo alto": ["CA"],
    "davis": ["CA"], "stanford": ["CA"], "rancho mirage": ["CA"],
    
    // Texas cities
    "el paso": ["TX"], "arlington": ["TX"], "corpus christi": ["TX"], "plano": ["TX"],
    "laredo": ["TX"], "lubbock": ["TX"], "garland": ["TX"], "irving": ["TX"],
    "amarillo": ["TX"], "grand prairie": ["TX"], "brownsville": ["TX"], "mckinney": ["TX"],
    "frisco": ["TX"], "pasadena": ["TX"], "mesquite": ["TX"], "mcallen": ["TX"],
    "killeen": ["TX"], "waco": ["TX"], "carrollton": ["TX"], "beaumont": ["TX"],
    "abilene": ["TX"], "round rock": ["TX"], "richardson": ["TX"], "odessa": ["TX"],
    "college station": ["TX"], "pearland": ["TX"], "midland": ["TX"], "wichita falls": ["TX"],
    "tyler": ["TX"], "lewisville": ["TX"], "denton": ["TX"], "san angelo": ["TX"],
    "league city": ["TX"], "allen": ["TX"], "edinburg": ["TX"], "sugar land": ["TX"],
    "san marcos": ["TX"], "the woodlands": ["TX"], "galveston": ["TX"],
    "mission": ["TX"], "bryan": ["TX"], "pharr": ["TX"], "baytown": ["TX"],
    
    // Florida cities
    "miami": ["FL"], "tampa": ["FL"], "orlando": ["FL"], "st. petersburg": ["FL"],
    "saint petersburg": ["FL"], "hialeah": ["FL"], "tallahassee": ["FL"], "fort lauderdale": ["FL"], "port st. lucie": ["FL"],
    "cape coral": ["FL"], "pembroke pines": ["FL"], "hollywood": ["FL"], "miramar": ["FL"],
    "coral springs": ["FL"], "clearwater": ["FL"], "miami gardens": ["FL"], "palm bay": ["FL"],
    "pompano beach": ["FL"], "west palm beach": ["FL"], "lakeland": ["FL"], "davie": ["FL"],
    "gainesville": ["FL"], "boca raton": ["FL"], "sunrise": ["FL"], "plantation": ["FL"],
    "melbourne": ["FL"], "boynton beach": ["FL"], "fort myers": ["FL"], "deerfield beach": ["FL"],
    "st. augustine": ["FL"], "saint augustine": ["FL"], "st. cloud": ["FL"], "saint cloud": ["FL"],
    "st. pete beach": ["FL"], "saint pete beach": ["FL"], "bonita springs": ["FL"],
    "sarasota": ["FL"], "daytona beach": ["FL"], "kissimmee": ["FL"], "naples": ["FL"], 
    "aventura": ["FL"], "lake buena vista": ["FL"], "miami beach": ["FL"], "oviedo": ["FL"],
    
    // New York cities
    "buffalo": ["NY"], "rochester": ["NY"], "yonkers": ["NY"], "syracuse": ["NY"],
    "albany": ["NY"], "new rochelle": ["NY"], "mount vernon": ["NY"], "schenectady": ["NY"],
    "utica": ["NY"], "white plains": ["NY"], "hempstead": ["NY"], "troy": ["NY"],
    "niagara falls": ["NY"], "binghamton": ["NY"], "freeport": ["NY"], "valley stream": ["NY"],
    "verona": ["NY"],
    
    // Arizona cities
    "mesa": ["AZ"], "chandler": ["AZ"], "scottsdale": ["AZ"], "gilbert": ["AZ"],
    "glendale": ["AZ"], "tempe": ["AZ"], "peoria": ["AZ"], "surprise": ["AZ"],
    "yuma": ["AZ"], "avondale": ["AZ"], "goodyear": ["AZ"], "flagstaff": ["AZ"],
    "buckeye": ["AZ"], "lake havasu city": ["AZ"], "casa grande": ["AZ"], "sierra vista": ["AZ"],
    "maricopa": ["AZ"], "oro valley": ["AZ"], "prescott": ["AZ"], "bullhead city": ["AZ"],
    "tucson": ["AZ"],
    
    // Rest of USA cities (alphabetically by state)
    // Alabama
    "birmingham": ["AL", "UK"], "montgomery": ["AL"], "mobile": ["AL"], "huntsville": ["AL"],
    "tuscaloosa": ["AL"], "hoover": ["AL"], "dothan": ["AL"], "auburn": ["AL"],
    "decatur": ["AL"], "madison": ["AL"], "florence": ["AL"], "gadsden": ["AL"],
    "orange beach": ["AL"], "fairhope": ["AL"],
    
    // Alaska
    "anchorage": ["AK"], "fairbanks": ["AK"], "juneau": ["AK"], "sitka": ["AK"],
    "ketchikan": ["AK"], "wasilla": ["AK"], "kenai": ["AK"], "kodiak": ["AK"],
    
    // Arkansas  
    "little rock": ["AR"], "fort smith": ["AR"], "fayetteville": ["AR"], "springdale": ["AR"],
    "jonesboro": ["AR"], "north little rock": ["AR"], "conway": ["AR"], "rogers": ["AR"],
    "pine bluff": ["AR"], "bentonville": ["AR"], "hot springs": ["AR"], "benton": ["AR"],
    
    // Colorado
    "colorado springs": ["CO"], "aurora": ["CO"], "fort collins": ["CO"], "lakewood": ["CO"],
    "thornton": ["CO"], "arvada": ["CO"], "westminster": ["CO"], "pueblo": ["CO"],
    "centennial": ["CO"], "boulder": ["CO"], "greeley": ["CO"], "longmont": ["CO"],
    "loveland": ["CO"], "grand junction": ["CO"], "broomfield": ["CO"], "castle rock": ["CO"],
    "golden": ["CO"], "dillon": ["CO"], "glenwood springs": ["CO"], "vail": ["CO"],
    
    // Connecticut
    "bridgeport": ["CT"], "new haven": ["CT"], "stamford": ["CT"], "hartford": ["CT"],
    "waterbury": ["CT"], "norwalk": ["CT"], "danbury": ["CT"], "new britain": ["CT"],
    "meriden": ["CT"], "bristol": ["CT"], "west haven": ["CT"], "milford": ["CT"],
    "north haven": ["CT"], "middletown": ["CT"], "portland": ["CT"],
    
    // Delaware
    "wilmington": ["DE"], "dover": ["DE"], "newark": ["DE"], "middletown": ["DE"],
    "smyrna": ["DE"], "milford": ["DE"], "seaford": ["DE"], "georgetown": ["DE"],
    
    // Georgia
    "atlanta": ["GA"], "augusta": ["GA"], "columbus": ["GA"], "macon": ["GA"],
    "savannah": ["GA"], "athens": ["GA"], "sandy springs": ["GA"], "roswell": ["GA"],
    "johns creek": ["GA"], "albany": ["GA"], "warner robins": ["GA"], "alpharetta": ["GA"],
    "marietta": ["GA"], "valdosta": ["GA"], "smyrna": ["GA"], "dunwoody": ["GA"],
    "jekyll island": ["GA"], "duluth": ["GA"], "carrollton": ["GA"],
    
    // Hawaii
    "honolulu": ["HI"], "pearl city": ["HI"], "hilo": ["HI"], "kailua": ["HI"],
    "waipahu": ["HI"], "kaneohe": ["HI"], "mililani": ["HI"], "ewa gentry": ["HI"],
    
    // Idaho
    "boise": ["ID"], "meridian": ["ID"], "nampa": ["ID"], "idaho falls": ["ID"],
    "pocatello": ["ID"], "caldwell": ["ID"], "coeur d'alene": ["ID"], "twin falls": ["ID"],
    "sun valley": ["ID"],
    
    // Illinois
    "naperville": ["IL"], "joliet": ["IL"], "rockford": ["IL"], "springfield": ["IL"],
    "elgin": ["IL"], "peoria": ["IL"], "champaign": ["IL"], "waukegan": ["IL"],
    "evanston": ["IL"],
    "cicero": ["IL"], "bloomington": ["IL"], "arlington heights": ["IL"], "evanston": ["IL"],
    "decatur": ["IL"], "schaumburg": ["IL"], "bolingbrook": ["IL"], "palatine": ["IL"],
    "east peoria": ["IL"], "normal": ["IL"],
    
    // Indiana
    "fort wayne": ["IN"], "evansville": ["IN"], "south bend": ["IN"], "carmel": ["IN"],
    "fishers": ["IN"], "bloomington": ["IN"], "hammond": ["IN"], "gary": ["IN"],
    "muncie": ["IN"], "lafayette": ["IN"], "terre haute": ["IN"], "kokomo": ["IN"],
    "west lafayette": ["IN"], "noblesville": ["IN"], "madison": ["IN"],
    
    // Iowa
    "des moines": ["IA"], "cedar rapids": ["IA"], "davenport": ["IA"], "sioux city": ["IA"],
    "iowa city": ["IA"], "waterloo": ["IA"], "council bluffs": ["IA"], "ames": ["IA"],
    "west des moines": ["IA"], "dubuque": ["IA"], "ankeny": ["IA"], "urbandale": ["IA"],
    "solon": ["IA"],
    
    // Kansas
    "wichita": ["KS"], "overland park": ["KS"], "kansas city": ["KS", "MO"], "olathe": ["KS"],
    "topeka": ["KS"], "lawrence": ["KS"], "shawnee": ["KS"], "manhattan": ["KS"],
    "lenexa": ["KS"], "salina": ["KS"], "hutchinson": ["KS"], "leavenworth": ["KS"],
    
    // Kentucky
    "louisville": ["KY"], "lexington": ["KY"], "bowling green": ["KY"], "owensboro": ["KY"],
    "covington": ["KY"], "richmond": ["KY"], "georgetown": ["KY"], "florence": ["KY"],
    "hopkinsville": ["KY"], "nicholasville": ["KY"], "elizabethtown": ["KY"], "henderson": ["KY"],
    
    // Louisiana
    "new orleans": ["LA"], "baton rouge": ["LA"], "shreveport": ["LA"], "lafayette": ["LA"],
    "lake charles": ["LA"], "kenner": ["LA"], "bossier city": ["LA"], "monroe": ["LA"],
    "alexandria": ["LA"], "houma": ["LA"], "metairie": ["LA"], "central": ["LA"],
    
    // Maine
    "portland": ["OR", "ME"], "lewiston": ["ME"], "bangor": ["ME"], "south portland": ["ME"],
    "auburn": ["ME"], "biddeford": ["ME"], "sanford": ["ME"], "saco": ["ME"],
    "rockport": ["ME"],
    
    // Maryland
    "baltimore": ["MD"], "columbia": ["MD"], "germantown": ["MD"], "silver spring": ["MD"],
    "waldorf": ["MD"], "glen burnie": ["MD"], "ellicott city": ["MD"], "frederick": ["MD"],
    "dundalk": ["MD"], "rockville": ["MD"], "bethesda": ["MD"], "gaithersburg": ["MD"],
    "national harbor": ["MD"], "college park": ["MD"], "cambridge": ["MD"],
    
    // Massachusetts
    "worcester": ["MA"], "springfield": ["MA"], "cambridge": ["MA"], "lowell": ["MA"],
    "brockton": ["MA"], "quincy": ["MA"], "lynn": ["MA"], "new bedford": ["MA"],
    "fall river": ["MA"], "newton": ["MA"], "lawrence": ["MA"], "somerville": ["MA"],
    "framingham": ["MA"], "haverhill": ["MA"], "waltham": ["MA"], "malden": ["MA"],
    
    // Michigan
    "detroit": ["MI"], "grand rapids": ["MI"], "warren": ["MI"], "sterling heights": ["MI"],
    "ann arbor": ["MI"], "lansing": ["MI"], "flint": ["MI"], "dearborn": ["MI"],
    "livonia": ["MI"], "westland": ["MI"], "troy": ["MI"], "farmington hills": ["MI"],
    "kalamazoo": ["MI"], "wyoming": ["MI"], "southfield": ["MI"], "rochester hills": ["MI"],
    "traverse city": ["MI"],
    
    // Minnesota
    "minneapolis": ["MN"], "st. paul": ["MN"], "saint paul": ["MN"], "rochester": ["MN", "NY", "NH"],
    "duluth": ["MN"], "bloomington": ["MN"], "brooklyn park": ["MN"], "plymouth": ["MN"],
    "st. cloud": ["MN"], "saint cloud": ["MN"], "eagan": ["MN"], "woodbury": ["MN"], "maple grove": ["MN"],
    "brainerd": ["MN"],
    
    // Mississippi
    "jackson": ["MS"], "gulfport": ["MS"], "southaven": ["MS"], "hattiesburg": ["MS"],
    "biloxi": ["MS"], "meridian": ["MS"], "tupelo": ["MS"], "greenville": ["MS"],
    "olive branch": ["MS"], "horn lake": ["MS"], "clinton": ["MS"], "madison": ["MS"],
    "nesbit": ["MS"],
    
    // Missouri
    "kansas city": ["MO", "KS"], "st. louis": ["MO"], "saint louis": ["MO"], "springfield": ["MO"], "columbia": ["MO", "SC"],
    "independence": ["MO"], "lee's summit": ["MO"], "o'fallon": ["MO"], "st. joseph": ["MO"], "saint joseph": ["MO"],
    "st. charles": ["MO"], "saint charles": ["MO"], "st. peters": ["MO"], "saint peters": ["MO"], "blue springs": ["MO"], "florissant": ["MO"],
    "chesterfield": ["MO"],
    
    // Montana
    "billings": ["MT"], "missoula": ["MT"], "great falls": ["MT"], "bozeman": ["MT"],
    "butte": ["MT"], "helena": ["MT"], "kalispell": ["MT"], "havre": ["MT"],
    
    // Nebraska
    "omaha": ["NE"], "lincoln": ["NE"], "bellevue": ["NE"], "grand island": ["NE"],
    "kearney": ["NE"], "fremont": ["NE"], "hastings": ["NE"], "norfolk": ["NE"],
    
    // Nevada
    "las vegas": ["NV"], "henderson": ["NV"], "reno": ["NV"], "north las vegas": ["NV"],
    "sparks": ["NV"], "carson city": ["NV"], "fernley": ["NV"], "elko": ["NV"],
    "stateline": ["NV"], "lake tahoe": ["NV"],
    
    // New Hampshire
    "manchester": ["NH"], "nashua": ["NH"], "concord": ["NH", "CA"], "derry": ["NH"],
    "rochester": ["NH", "NY", "MN"], "salem": ["NH", "OR", "MA"], "merrimack": ["NH"], "hudson": ["NH"],
    "portsmouth": ["NH"],
    
    // New Jersey
    "newark": ["NJ"], "jersey city": ["NJ"], "paterson": ["NJ"], "elizabeth": ["NJ"],
    "edison": ["NJ"], "woodbridge": ["NJ"], "lakewood": ["NJ"], "toms river": ["NJ"],
    "hamilton": ["NJ"], "trenton": ["NJ"], "clifton": ["NJ"], "camden": ["NJ"],
    "somerset": ["NJ"], "atlantic city": ["NJ"],
    
    // New Mexico
    "albuquerque": ["NM"], "las cruces": ["NM"], "rio rancho": ["NM"], "santa fe": ["NM"],
    "roswell": ["NM"], "farmington": ["NM"], "south valley": ["NM"], "clovis": ["NM"],
    
    // North Carolina
    "raleigh": ["NC"], "greensboro": ["NC"], "durham": ["NC"], "winston-salem": ["NC"],
    "fayetteville": ["NC"], "cary": ["NC"], "wilmington": ["NC"], "high point": ["NC"],
    "concord": ["NC", "CA", "NH"], "gastonia": ["NC"], "asheville": ["NC"], "greenville": ["NC"],
    
    // North Dakota
    "fargo": ["ND"], "bismarck": ["ND"], "grand forks": ["ND"], "minot": ["ND"],
    "west fargo": ["ND"], "williston": ["ND"], "dickinson": ["ND"], "mandan": ["ND"],
    
    // Ohio
    "cleveland": ["OH"], "cincinnati": ["OH"], "toledo": ["OH"], "akron": ["OH"],
    "dayton": ["OH"], "parma": ["OH"], "canton": ["OH"], "youngstown": ["OH"],
    "lorain": ["OH"], "hamilton": ["OH"], "springfield": ["OH", "IL", "MA", "MO"], "kettering": ["OH"], "elyria": ["OH"],
    "dublin": ["OH"], "sandusky": ["OH"], "west portsmouth": ["OH"],
    
    // Oklahoma
    "oklahoma city": ["OK"], "tulsa": ["OK"], "norman": ["OK"], "broken arrow": ["OK"],
    "lawton": ["OK"], "edmond": ["OK"], "moore": ["OK"], "midwest city": ["OK"],
    "enid": ["OK"], "stillwater": ["OK"], "muskogee": ["OK"], "bartlesville": ["OK"],
    
    // Oregon
    "portland": ["OR", "ME"], "salem": ["OR", "MA", "NH"], "eugene": ["OR"], "gresham": ["OR"],
    "hillsboro": ["OR"], "beaverton": ["OR"], "bend": ["OR"], "medford": ["OR"],
    "springfield": ["OR", "IL", "MA", "MO", "OH"], "corvallis": ["OR"], "albany": ["OR"], "tigard": ["OR"],
    "sunriver": ["OR"], "woodburn": ["OR"], "lincoln city": ["OR"], "oregon city": ["OR"],
    
    // Pennsylvania
    "pittsburgh": ["PA"], "allentown": ["PA"], "erie": ["PA"], "reading": ["PA"],
    "scranton": ["PA"], "bethlehem": ["PA"], "lancaster": ["PA", "CA", "UK"], "harrisburg": ["PA"],
    "altoona": ["PA"], "york": ["PA"], "state college": ["PA"], "wilkes-barre": ["PA"],
    "hershey": ["PA"], "blue bell": ["PA"], "pottstown": ["PA"], "dallas": ["PA", "TX"],
    "dubois": ["PA"], "pocono manor": ["PA"], "indiana": ["PA", "IN"], "abington": ["PA"],
    "drexel hill": ["PA"],
    
    // Rhode Island
    "providence": ["RI"], "warwick": ["RI"], "cranston": ["RI"], "pawtucket": ["RI"],
    "east providence": ["RI"], "woonsocket": ["RI"], "coventry": ["RI"], "cumberland": ["RI"],
    "newport": ["RI", "VT", "UK"],
    
    // South Carolina
    "columbia": ["SC", "MO"], "charleston": ["SC", "WV"], "north charleston": ["SC"], "mount pleasant": ["SC"],
    "rock hill": ["SC"], "greenville": ["SC"], "summerville": ["SC"], "goose creek": ["SC"],
    "hilton head island": ["SC"], "sumter": ["SC"], "florence": ["SC"], "spartanburg": ["SC"],
    "chester": ["SC"], "myrtle beach": ["SC"],
    
    // South Dakota
    "sioux falls": ["SD"], "rapid city": ["SD"], "aberdeen": ["SD"], "brookings": ["SD"],
    "watertown": ["SD"], "mitchell": ["SD"], "yankton": ["SD"], "pierre": ["SD"],
    
    // Tennessee
    "memphis": ["TN"], "nashville": ["TN"], "knoxville": ["TN"], "chattanooga": ["TN"],
    "clarksville": ["TN"], "murfreesboro": ["TN"], "jackson": ["TN"], "franklin": ["TN"],
    "johnson city": ["TN"], "bartlett": ["TN"], "hendersonville": ["TN"], "kingsport": ["TN"],
    "gatlinburg": ["TN"],
    
    // Utah
    "salt lake city": ["UT"], "west valley city": ["UT"], "provo": ["UT"], "west jordan": ["UT"],
    "orem": ["UT"], "sandy": ["UT"], "ogden": ["UT"], "st. george": ["UT"],
    "layton": ["UT"], "south jordan": ["UT"], "lehi": ["UT"], "millcreek": ["UT"],
    "ivins": ["UT"], "midvale": ["UT"], "kanab": ["UT"], "bryce canyon city": ["UT"], "cedar city": ["UT"],
    
    // Vermont
    "burlington": ["VT"], "south burlington": ["VT"], "rutland": ["VT"], "barre": ["VT"],
    "montpelier": ["VT"], "winooski": ["VT"], "st. albans": ["VT"], "newport": ["VT"],
    
    // Virginia
    "virginia beach": ["VA"], "norfolk": ["VA"], "chesapeake": ["VA"], "richmond": ["VA", "CA", "VT"],
    "newport news": ["VA"], "alexandria": ["VA"], "hampton": ["VA"], "roanoke": ["VA"],
    "portsmouth": ["VA"], "suffolk": ["VA"], "lynchburg": ["VA"], "harrisonburg": ["VA"],
    "charlottesville": ["VA"], "petersburg": ["VA"], "blacksburg": ["VA"], "fairfax": ["VA"],
    
    // Washington
    "seattle": ["WA"], "spokane": ["WA"], "tacoma": ["WA"], "vancouver": ["WA"],
    "bellevue": ["WA"], "kent": ["WA"], "everett": ["WA"], "renton": ["WA"],
    "spokane valley": ["WA"], "federal way": ["WA"], "yakima": ["WA"], "kirkland": ["WA"],
    "richland": ["WA"],
    
    // West Virginia
    "charleston": ["WV", "SC"], "huntington": ["WV"], "morgantown": ["WV"], "parkersburg": ["WV"],
    "wheeling": ["WV"], "weirton": ["WV"], "fairmont": ["WV"], "beckley": ["WV"],
    "lewisburg": ["WV"], "white sulphur springs": ["WV"],
    
    // Wisconsin
    "milwaukee": ["WI"], "madison": ["WI"], "green bay": ["WI"], "kenosha": ["WI"],
    "racine": ["WI"], "appleton": ["WI"], "waukesha": ["WI"], "eau claire": ["WI"],
    "oshkosh": ["WI"], "janesville": ["WI"], "west allis": ["WI"], "la crosse": ["WI"],
    "stevens point": ["WI"],
    
    // Wyoming
    "cheyenne": ["WY"], "casper": ["WY"], "laramie": ["WY"], "gillette": ["WY"],
    "rock springs": ["WY"], "sheridan": ["WY"], "green river": ["WY"], "evanston": ["WY"],
    
    // Puerto Rico
    "san juan": ["PR"], "bayamón": ["PR"], "carolina": ["PR"], "ponce": ["PR"],
    
    // Additional duplicate city names across multiple states
    "texarkana": ["TX", "AR"], "union city": ["NJ", "CA", "GA", "TN"], 
    "bristol": ["CT", "TN", "VA", "RI", "UK"], "texhoma": ["TX", "OK"],
    "clinton": ["UT", "MS", "MA", "IA", "IL", "MD", "MI", "MO", "NC", "OK", "SC", "TN"],
    "franklin": ["TN", "MA", "NH", "PA", "WI", "IN", "KY", "LA", "NC", "OH", "VA"],
    "washington": ["DC", "PA", "NC", "IN", "IL", "IA", "KS", "MO", "UT"],
    "lebanon": ["TN", "PA", "NH", "OR", "IN", "IL", "KY", "MO", "OH"],
    "oxford": ["MS", "OH", "MA"], "bedford": ["TX", "MA", "NH", "IN", "OH", "PA", "VA"],
    "newton": ["MA", "IA", "KS", "NC", "NJ"], "ashland": ["OR", "KY", "OH", "WI", "VA", "MA", "NE"],
    "clayton": ["MO", "NC", "NJ", "CA", "GA"], "greenville": ["SC", "NC", "MS", "TX", "OH", "MI", "IL"],
    "dover": ["DE", "NH", "NJ", "OH", "FL"], "monroe": ["LA", "MI", "NC", "WA", "WI", "GA", "CT"],
    "troy": ["NY", "MI", "OH", "AL", "MO"], "auburn": ["AL", "CA", "ME", "MA", "NY", "WA", "IN"],
    "independence": ["MO", "KS", "OR", "IA", "KY"], "fairview": ["OR", "NJ", "TN", "TX"],
    "georgetown": ["TX", "KY", "SC", "DE"], "marion": ["OH", "IN", "IL", "IA", "AR"],
    "florence": ["AL", "KY", "SC", "Italy"], "lancaster": ["PA", "CA", "UK"],
    "wilmington": ["DE", "NC"], "jackson": ["MS", "TN", "MI"], "augusta": ["GA", "ME"],
    "bellevue": ["WA", "NE"], "manchester": ["NH", "UK"], "salem": ["OR", "MA", "NH"],
    "newark": ["NJ", "DE"], "bloomington": ["IL", "IN", "MN"],
    "springfield": ["IL", "MA", "MO", "OH", "OR"], "columbia": ["SC", "MO", "MD"],
    "charleston": ["SC", "WV"], "richmond": ["VA", "CA"], "lafayette": ["LA", "IN"],
    "rochester": ["NY", "MN", "NH"], "concord": ["NH", "CA", "NC"], "cambridge": ["MA", "UK"],
    "columbus": ["OH", "GA", "IN", "MS"], "quincy": ["IL", "MA"], "arlington": ["TX", "VA"],
    
    // St./Saint city variations - USA
    "st. louis": ["MO"], "saint louis": ["MO"], "st. paul": ["MN"], "saint paul": ["MN"],
    "st. petersburg": ["FL"], "saint petersburg": ["FL"], "st. cloud": ["FL", "MN"], "saint cloud": ["FL", "MN"],
    "st. joseph": ["MO"], "saint joseph": ["MO"], "st. charles": ["MO", "IL"], "saint charles": ["MO", "IL"],
    "st. peters": ["MO"], "saint peters": ["MO"], "st. augustine": ["FL"], "saint augustine": ["FL"],
    "st. george": ["UT"], "saint george": ["UT"], "st. albans": ["VT", "WV"], "saint albans": ["VT", "WV"],
    "st. helens": ["OR"], "saint helens": ["OR"], "st. clair shores": ["MI"], "saint clair shores": ["MI"],
    "st. john": ["IN"], "saint john": ["IN"], "st. marys": ["GA", "PA"], "saint marys": ["GA", "PA"]
  },
  
  // European Cities - COMPREHENSIVE LIST
  europe: {
    // UK Cities (displayed as "City, UK")
    "london": "UK", "birmingham": "UK", "glasgow": "UK",
    "liverpool": "UK", "edinburgh": "UK", "leeds": "UK", "bristol": "UK",
    "cardiff": "UK", "sheffield": "UK", "newcastle": "UK", "belfast": "UK",
    "nottingham": "UK", "leicester": "UK", "southampton": "UK", "oxford": "UK",
    "cambridge": "UK", "york": "UK", "bath": "UK", "brighton": "UK",
    "plymouth": "UK", "portsmouth": "UK", "reading": "UK", "coventry": "UK",
    "sunderland": "UK", "aberdeen": "UK", "dundee": "UK", "swansea": "UK",
    "wolverhampton": "UK", "derby": "UK", "stoke-on-trent": "UK", "hull": "UK",
    
    // Additional UK cities - England
    "bradford": "UK", "norwich": "UK", "milton keynes": "UK", "peterborough": "UK",
    "luton": "UK", "preston": "UK", "blackpool": "UK", "bournemouth": "UK",
    "exeter": "UK", "gloucester": "UK", "ipswich": "UK", "colchester": "UK",
    "canterbury": "UK", "chester": "UK", "durham": "UK", "lancaster": "UK",
    "lincoln": "UK", "salisbury": "UK", "winchester": "UK", "worcester": "UK",
    "carlisle": "UK", "newcastle upon tyne": "UK", "sunderland": "UK",
    "middlesbrough": "UK", "bolton": "UK", "oldham": "UK", "blackburn": "UK",
    "rochdale": "UK", "stockport": "UK", "salford": "UK", "wigan": "UK",
    "st helens": "UK", "southend-on-sea": "UK", "warrington": "UK",
    
    // Wales cities
    "newport": "UK", "wrexham": "UK", "bangor": "UK", "st davids": "UK",
    "st asaph": "UK", "llanelli": "UK", "barry": "UK", "neath": "UK",
    
    // Scotland cities  
    "stirling": "UK", "perth": "UK", "inverness": "UK", "kilmarnock": "UK",
    "paisley": "UK", "livingston": "UK", "hamilton": "UK", "kirkcaldy": "UK",
    "greenock": "UK", "ayr": "UK", "falkirk": "UK", "cumbernauld": "UK",
    "dunfermline": "UK",
    
    // Northern Ireland cities
    "londonderry": "UK", "derry": "UK", "lisburn": "UK", "newry": "UK",
    "armagh": "UK", "bangor": "UK", "craigavon": "UK", "ballymena": "UK",
    
    // France
    "paris": "France", "marseille": "France", "lyon": "France", "toulouse": "France",
    "nice": "France", "nantes": "France", "strasbourg": "France", "montpellier": "France",
    "bordeaux": "France", "lille": "France", "rennes": "France", "reims": "France",
    "le havre": "France", "saint-étienne": "France", "toulon": "France", "grenoble": "France",
    "dijon": "France", "angers": "France", "nîmes": "France", "villeurbanne": "France",
    "clermont-ferrand": "France", "le mans": "France", "aix-en-provence": "France",
    "brest": "France", "tours": "France", "amiens": "France", "limoges": "France",
    "annecy": "France", "perpignan": "France", "boulogne-billancourt": "France",
    
    // Germany
    "berlin": "Germany", "hamburg": "Germany", "munich": "Germany", "cologne": "Germany",
    "frankfurt": "Germany", "stuttgart": "Germany", "düsseldorf": "Germany", "dortmund": "Germany",
    "essen": "Germany", "leipzig": "Germany", "bremen": "Germany", "dresden": "Germany",
    "hanover": "Germany", "nuremberg": "Germany", "duisburg": "Germany", "bochum": "Germany",
    "wuppertal": "Germany", "bielefeld": "Germany", "bonn": "Germany", "münster": "Germany",
    "karlsruhe": "Germany", "mannheim": "Germany", "augsburg": "Germany", "wiesbaden": "Germany",
    "gelsenkirchen": "Germany", "mönchengladbach": "Germany", "braunschweig": "Germany",
    "chemnitz": "Germany", "kiel": "Germany", "aachen": "Germany",
    "kaiserslautern": "Germany", "erfurt": "Germany",
    
    // Spain
    "madrid": "Spain", "barcelona": "Spain", "valencia": "Spain", "seville": "Spain",
    "zaragoza": "Spain", "málaga": "Spain", "murcia": "Spain", "palma": "Spain",
    "las palmas": "Spain", "bilbao": "Spain", "alicante": "Spain", "córdoba": "Spain",
    "valladolid": "Spain", "vigo": "Spain", "gijón": "Spain", "hospitalet": "Spain",
    "vitoria": "Spain", "coruña": "Spain", "granada": "Spain", "elche": "Spain",
    "oviedo": "Spain", "badalona": "Spain", "cartagena": "Spain", "terrassa": "Spain",
    "jerez": "Spain", "sabadell": "Spain", "santa cruz": "Spain", "pamplona": "Spain",
    "almería": "Spain", "fuenlabrada": "Spain",
    
    // Italy
    "rome": "Italy", "milan": "Italy", "naples": "Italy", "turin": "Italy",
    "palermo": "Italy", "genoa": "Italy", "bologna": "Italy", "florence": "Italy",
    "bari": "Italy", "catania": "Italy", "venice": "Italy", "verona": "Italy",
    "messina": "Italy", "padua": "Italy", "trieste": "Italy", "brescia": "Italy",
    "taranto": "Italy", "prato": "Italy", "parma": "Italy", "modena": "Italy",
    "reggio calabria": "Italy", "reggio emilia": "Italy", "perugia": "Italy",
    "ravenna": "Italy", "livorno": "Italy", "cagliari": "Italy", "foggia": "Italy",
    "rimini": "Italy", "salerno": "Italy", "ferrara": "Italy",
    
    // Netherlands
    "amsterdam": "Netherlands", "rotterdam": "Netherlands", "the hague": "Netherlands",
    "utrecht": "Netherlands", "eindhoven": "Netherlands", "tilburg": "Netherlands",
    "groningen": "Netherlands", "almere": "Netherlands", "breda": "Netherlands",
    "nijmegen": "Netherlands", "enschede": "Netherlands", "haarlem": "Netherlands",
    "arnhem": "Netherlands", "zaanstad": "Netherlands", "haarlemmermeer": "Netherlands",
    "apeldoorn": "Netherlands", "amersfoort": "Netherlands", "maastricht": "Netherlands",
    "leiden": "Netherlands", "dordrecht": "Netherlands",
    
    // Poland - COMPREHENSIVE
    "warsaw": "Poland", "krakow": "Poland", "lodz": "Poland", "wroclaw": "Poland",
    "poznan": "Poland", "gdansk": "Poland", "szczecin": "Poland", "bydgoszcz": "Poland",
    "lublin": "Poland", "katowice": "Poland", "bialystok": "Poland", "gdynia": "Poland",
    "czestochowa": "Poland", "radom": "Poland", "sosnowiec": "Poland", "torun": "Poland",
    "kielce": "Poland", "gliwice": "Poland", "zabrze": "Poland", "bytom": "Poland",
    "olsztyn": "Poland", "bielsko-biala": "Poland", "rzeszow": "Poland", "ruda slaska": "Poland",
    "rybnik": "Poland", "tychy": "Poland", "dabrowa gornicza": "Poland", "plock": "Poland",
    
    // Balkans - Bosnia, Serbia, Croatia, Slovenia, etc.
    "sarajevo": "Bosnia and Herzegovina", "banja luka": "Bosnia and Herzegovina",
    "tuzla": "Bosnia and Herzegovina", "zenica": "Bosnia and Herzegovina", "mostar": "Bosnia and Herzegovina",
    "belgrade": "Serbia", "novi sad": "Serbia", "nis": "Serbia", "kragujevac": "Serbia",
    "subotica": "Serbia", "zrenjanin": "Serbia", "pancevo": "Serbia",
    "zagreb": "Croatia", "split": "Croatia", "rijeka": "Croatia", "osijek": "Croatia",
    "zadar": "Croatia", "pula": "Croatia", "slavonski brod": "Croatia",
    "ljubljana": "Slovenia", "maribor": "Slovenia", "celje": "Slovenia", "kranj": "Slovenia",
    "bled": "Slovenia", "portorož": "Slovenia",
    "skopje": "North Macedonia", "bitola": "North Macedonia", "kumanovo": "North Macedonia", "prilep": "North Macedonia",
    "pristina": "Kosovo", "prizren": "Kosovo", "peja": "Kosovo", "gjakova": "Kosovo",
    "podgorica": "Montenegro", "niksic": "Montenegro", "pljevlja": "Montenegro", "bijelo polje": "Montenegro",
    "tirana": "Albania", "durres": "Albania", "vlore": "Albania", "elbasan": "Albania",
    "shkoder": "Albania", "kamez": "Albania", "fier": "Albania",
    
    // Romania - COMPREHENSIVE
    "bucharest": "Romania", "cluj-napoca": "Romania", "timisoara": "Romania",
    "iasi": "Romania", "constanta": "Romania", "craiova": "Romania", "brasov": "Romania",
    "galati": "Romania", "ploiesti": "Romania", "oradea": "Romania", "braila": "Romania",
    "arad": "Romania", "pitesti": "Romania", "sibiu": "Romania", "bacau": "Romania",
    "targu mures": "Romania", "baia mare": "Romania", "buzau": "Romania", "satu mare": "Romania",
    
    // Bulgaria
    "sofia": "Bulgaria", "plovdiv": "Bulgaria", "varna": "Bulgaria", "burgas": "Bulgaria",
    "ruse": "Bulgaria", "stara zagora": "Bulgaria", "pleven": "Bulgaria", "sliven": "Bulgaria",
    "dobrich": "Bulgaria", "shumen": "Bulgaria", "pernik": "Bulgaria", "haskovo": "Bulgaria",
    
    // Czech Republic
    "prague": "Czech Republic", "brno": "Czech Republic", "ostrava": "Czech Republic",
    "plzen": "Czech Republic", "liberec": "Czech Republic", "olomouc": "Czech Republic",
    "ceske budejovice": "Czech Republic", "hradec kralove": "Czech Republic", "usti nad labem": "Czech Republic",
    "malenovice": "Czech Republic",
    
    // Slovakia
    "bratislava": "Slovakia", "kosice": "Slovakia", "presov": "Slovakia", "nitra": "Slovakia",
    "zilina": "Slovakia", "banska bystrica": "Slovakia", "trnava": "Slovakia", "martin": "Slovakia",
    
    // Hungary
    "budapest": "Hungary", "debrecen": "Hungary", "szeged": "Hungary", "miskolc": "Hungary",
    "pecs": "Hungary", "gyor": "Hungary", "nyiregyhaza": "Hungary", "kecskemet": "Hungary",
    "szekesfehervar": "Hungary", "szombathely": "Hungary", "szolnok": "Hungary",
    
    // Greece
    "athens": "Greece", "thessaloniki": "Greece", "patras": "Greece", "heraklion": "Greece",
    "larissa": "Greece", "volos": "Greece", "rhodes": "Greece", "ioannina": "Greece",
    "chania": "Greece", "chalcis": "Greece", "agrinio": "Greece", "kalamata": "Greece",
    "corfu": "Greece",
    
    // Portugal
    "lisbon": "Portugal", "porto": "Portugal", "braga": "Portugal", "coimbra": "Portugal",
    "funchal": "Portugal", "amadora": "Portugal", "setubal": "Portugal", "almada": "Portugal",
    "agualva-cacem": "Portugal", "guimaraes": "Portugal", "leiria": "Portugal",
    
    // Austria
    "vienna": "Austria", "graz": "Austria", "linz": "Austria", "salzburg": "Austria",
    "innsbruck": "Austria", "klagenfurt": "Austria", "villach": "Austria", "wels": "Austria",
    
    // Belgium
    "brussels": "Belgium", "antwerp": "Belgium", "ghent": "Belgium", "charleroi": "Belgium",
    "liege": "Belgium", "bruges": "Belgium", "namur": "Belgium", "leuven": "Belgium",
    "mons": "Belgium", "aalst": "Belgium", "mechelen": "Belgium",
    
    // Switzerland
    "zurich": "Switzerland", "geneva": "Switzerland", "basel": "Switzerland",
    "lausanne": "Switzerland", "bern": "Switzerland", "winterthur": "Switzerland",
    "lucerne": "Switzerland", "st. gallen": "Switzerland", "lugano": "Switzerland",
    
    // Scandinavia
    "stockholm": "Sweden", "gothenburg": "Sweden", "malmö": "Sweden", "uppsala": "Sweden",
    "vasteras": "Sweden", "orebro": "Sweden", "linkoping": "Sweden", "helsingborg": "Sweden",
    "copenhagen": "Denmark", "aarhus": "Denmark", "odense": "Denmark", "aalborg": "Denmark",
    "esbjerg": "Denmark", "randers": "Denmark", "kolding": "Denmark",
    "oslo": "Norway", "bergen": "Norway", "trondheim": "Norway", "stavanger": "Norway",
    "drammen": "Norway", "fredrikstad": "Norway", "kristiansand": "Norway",
    "helsinki": "Finland", "espoo": "Finland", "tampere": "Finland", "vantaa": "Finland",
    "oulu": "Finland", "turku": "Finland", "jyvaskyla": "Finland", "lahti": "Finland",
    
    // Ireland
    "dublin": "Ireland", "cork": "Ireland", "limerick": "Ireland", "galway": "Ireland",
    "waterford": "Ireland", "drogheda": "Ireland", "dundalk": "Ireland", "swords": "Ireland",
    
    // Baltic States
    "riga": "Latvia", "daugavpils": "Latvia", "liepaja": "Latvia", "jelgava": "Latvia",
    "vilnius": "Lithuania", "kaunas": "Lithuania", "klaipeda": "Lithuania", "siauliai": "Lithuania",
    "tallinn": "Estonia", "tartu": "Estonia", "narva": "Estonia", "parnu": "Estonia",
    
    // Ukraine (major cities)
    "kyiv": "Ukraine", "kharkiv": "Ukraine", "odesa": "Ukraine", "dnipro": "Ukraine",
    "lviv": "Ukraine", "zaporizhzhia": "Ukraine", "kryvyi rih": "Ukraine", "mykolaiv": "Ukraine",
    
    // Belarus
    "minsk": "Belarus", "gomel": "Belarus", "mogilev": "Belarus", "vitebsk": "Belarus",
    "grodno": "Belarus", "brest": "Belarus",
    
    // Moldova
    "chisinau": "Moldova", "tiraspol": "Moldova", "balti": "Moldova", "bender": "Moldova",
    
    // Malta
    "valletta": "Malta", "birkirkara": "Malta", "mosta": "Malta", "qormi": "Malta",
    
    // Turkey / Türkiye
    "istanbul": "Turkey", "ankara": "Turkey", "izmir": "Turkey", "bursa": "Turkey",
    "antalya": "Turkey", "adana": "Turkey", "konya": "Turkey", "gaziantep": "Turkey",
    
    // Cyprus
    "nicosia": "Cyprus", "limassol": "Cyprus", "larnaca": "Cyprus", "famagusta": "Cyprus",
    
    // Additional UK cities
    "gateshead": "UK", "harrogate": "UK", "chelmsford": "UK",
    "surrey": "UK", "sussex": "UK",
    
    // Sweden
    "stockholm": "Sweden", "gothenburg": "Sweden", "malmö": "Sweden", "uppsala": "Sweden",
    "lund": "Sweden", "umeå": "Sweden", "djurhamn": "Sweden",
    
    // Iceland
    "reykjavík": "Iceland", "kópavogur": "Iceland", "hafnarfjörður": "Iceland",
    
    // Austria
    "vienna": "Austria", "graz": "Austria", "linz": "Austria", "salzburg": "Austria",
    "bad ischl": "Austria",
    
    // Croatia
    "zagreb": "Croatia", "split": "Croatia", "rijeka": "Croatia", "osijek": "Croatia",
    "opatija": "Croatia",
    
    // Belgium
    "brussels": "Belgium", "antwerp": "Belgium", "ghent": "Belgium", "charleroi": "Belgium",
    "hasselt": "Belgium",
    
    // Finland
    "helsinki": "Finland", "espoo": "Finland", "tampere": "Finland", "vantaa": "Finland",
    "joensuu": "Finland",
    
    // Norway
    "oslo": "Norway", "bergen": "Norway", "trondheim": "Norway", "stavanger": "Norway",
    "tromsø": "Norway",
    
    // Georgia (country)
    "tbilisi": "Georgia", "batumi": "Georgia", "kutaisi": "Georgia", "rustavi": "Georgia"
  }
};
