// Toolbar popup functionality

// Use browser API for Firefox
const browserAPI = (typeof browser !== 'undefined') ? browser : chrome;

// Storage wrapper
const storage = {
  get: function(keys) {
    return new Promise((resolve) => {
      try {
        if (browserAPI && browserAPI.storage && browserAPI.storage.sync) {
          browserAPI.storage.sync.get(keys).then(resolve).catch(() => {
            this._getFromLocalStorage(keys).then(resolve);
          });
        } else {
          this._getFromLocalStorage(keys).then(resolve);
        }
      } catch (error) {
        this._getFromLocalStorage(keys).then(resolve);
      }
    });
  },
  
  set: function(items) {
    return new Promise((resolve) => {
      try {
        if (browserAPI && browserAPI.storage && browserAPI.storage.sync) {
          browserAPI.storage.sync.set(items).then(resolve).catch(() => {
            this._setToLocalStorage(items).then(resolve);
          });
        } else {
          this._setToLocalStorage(items).then(resolve);
        }
      } catch (error) {
        this._setToLocalStorage(items).then(resolve);
      }
    });
  },
  
  _getFromLocalStorage: function(keys) {
    return new Promise((resolve) => {
      const result = {};
      keys.forEach(key => {
        const value = localStorage.getItem('smartTextHelper_' + key);
        if (value !== null) {
          try {
            result[key] = JSON.parse(value);
          } catch (e) {
            result[key] = value;
          }
        }
      });
      resolve(result);
    });
  },
  
  _setToLocalStorage: function(items) {
    return new Promise((resolve) => {
      Object.keys(items).forEach(key => {
        localStorage.setItem('smartTextHelper_' + key, JSON.stringify(items[key]));
      });
      resolve();
    });
  }
};

// Load current settings and update UI
storage.get(['enableUSA', 'enableEurope', 'regionHotkey']).then((result) => {
  const enableUSA = result.enableUSA !== undefined ? result.enableUSA : true;
  const enableEurope = result.enableEurope !== undefined ? result.enableEurope : true;
  const hotkey = result.regionHotkey || 'Alt+R';
  
  updateButtons(enableUSA, enableEurope);
  document.getElementById('hotkeyDisplay').textContent = hotkey;
});

function updateButtons(usa, europe) {
  const bothBtn = document.getElementById('bothBtn');
  const usaBtn = document.getElementById('usaBtn');
  const europeBtn = document.getElementById('europeBtn');
  
  bothBtn.classList.remove('active');
  usaBtn.classList.remove('active');
  europeBtn.classList.remove('active');
  
  if (usa && europe) {
    bothBtn.classList.add('active');
  } else if (usa && !europe) {
    usaBtn.classList.add('active');
  } else if (!usa && europe) {
    europeBtn.classList.add('active');
  }
}

// Button click handlers
document.getElementById('bothBtn').addEventListener('click', () => {
  storage.set({enableUSA: true, enableEurope: true});
  updateButtons(true, true);
});

document.getElementById('usaBtn').addEventListener('click', () => {
  storage.set({enableUSA: true, enableEurope: false});
  updateButtons(true, false);
});

document.getElementById('europeBtn').addEventListener('click', () => {
  storage.set({enableUSA: false, enableEurope: true});
  updateButtons(false, true);
});

// Settings button
document.getElementById('settingsBtn').addEventListener('click', () => {
  if (browserAPI && browserAPI.runtime && browserAPI.runtime.openOptionsPage) {
    browserAPI.runtime.openOptionsPage();
  }
});
