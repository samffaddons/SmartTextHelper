(function() {
  'use strict';

  // Storage wrapper with localStorage fallback
  const browserStorageAPI = (typeof browser !== 'undefined' && browser.storage) ? browser : 
                            (typeof chrome !== 'undefined' && chrome.storage) ? chrome : null;

  const storage = {
    get: function(keys) {
      return new Promise((resolve) => {
        try {
          if (browserStorageAPI && browserStorageAPI.storage && browserStorageAPI.storage.sync) {
            browserStorageAPI.storage.sync.get(keys).then(resolve).catch(() => {
              this._getFromLocalStorage(keys).then(resolve);
            });
          } else {
            this._getFromLocalStorage(keys).then(resolve);
          }
        } catch (error) {
          this._getFromLocalStorage(keys).then(resolve);
        }
      });
    },
    
    _getFromLocalStorage: function(keys) {
      return new Promise((resolve) => {
        const result = {};
        const keyArray = Array.isArray(keys) ? keys : [keys];
        
        keyArray.forEach(key => {
          const value = localStorage.getItem('smartTextHelper_' + key);
          if (value !== null) {
            try {
              result[key] = JSON.parse(value);
            } catch (e) {
              result[key] = value;
            }
          }
        });
        
        resolve(result);
      });
    },
    
    onChanged: {
      addListener: function(callback) {
        if (browserStorageAPI && browserStorageAPI.storage && browserStorageAPI.storage.onChanged) {
          browserStorageAPI.storage.onChanged.addListener(callback);
        }
        // Also listen to storage events for localStorage
        window.addEventListener('storage', (e) => {
          if (e.key && e.key.startsWith('smartTextHelper_')) {
            const key = e.key.replace('smartTextHelper_', '');
            const changes = {};
            changes[key] = { newValue: JSON.parse(e.newValue), oldValue: JSON.parse(e.oldValue) };
            callback(changes, 'sync');
          }
        });
      }
    }
  };

  let popup = null;
  let inputPopup = null;
  let currentData = null;
  let currentRange = null;
  let currentSelection = null;
  let linksToRemove = []; // Store actual link elements to remove
  let popupPosition = 'top';
  let enableHyperlink = true; // Setting for hyperlink feature
  let removeHyperlink = false; // Setting for remove hyperlink feature
  let autoCopy = false; // Auto-copy city names setting
  let autoCopyUnique = false; // Auto-copy only unique cities setting
  let customCities = {}; // Custom user-added cities
  let enableUSA = true; // Enable USA cities detection
  let enableEurope = true; // Enable Europe cities detection
  let selectionTimeout = null;
  let isProcessingSelection = false; // Flag to prevent duplicate processing
  let lastPopupTime = 0; // Timestamp of last popup creation
  
  // Load settings
  storage.get(['popupPosition', 'enableHyperlink', 'customCities', 'autoCopy', 'autoCopyUnique', 'removeHyperlink', 'enableUSA', 'enableEurope']).then((result) => {
    popupPosition = result.popupPosition || 'top';
    enableHyperlink = result.enableHyperlink !== undefined ? result.enableHyperlink : true;
    customCities = result.customCities || {};
    autoCopy = result.autoCopy || false;
    autoCopyUnique = result.autoCopyUnique || false;
    removeHyperlink = result.removeHyperlink || false;
    enableUSA = result.enableUSA !== undefined ? result.enableUSA : true;
    enableEurope = result.enableEurope !== undefined ? result.enableEurope : true;
    console.log('[Smart Text Helper] Settings loaded:', { popupPosition, enableHyperlink, customCities, autoCopy, autoCopyUnique, removeHyperlink, enableUSA, enableEurope });
  }).catch((error) => {
    console.error('[Smart Text Helper] Error loading settings:', error);
  });

  storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
      if (changes.popupPosition) {
        popupPosition = changes.popupPosition.newValue;
        console.log('[Smart Text Helper] Position changed to:', popupPosition);
      }
      if (changes.enableHyperlink) {
        enableHyperlink = changes.enableHyperlink.newValue;
        console.log('[Smart Text Helper] Hyperlink feature changed to:', enableHyperlink);
      }
      if (changes.customCities) {
        customCities = changes.customCities.newValue || {};
        console.log('[Smart Text Helper] Custom cities changed to:', customCities);
      }
      if (changes.autoCopy) {
        autoCopy = changes.autoCopy.newValue || false;
        console.log('[Smart Text Helper] Auto-copy changed to:', autoCopy);
      }
      if (changes.autoCopyUnique) {
        autoCopyUnique = changes.autoCopyUnique.newValue || false;
        console.log('[Smart Text Helper] Auto-copy unique changed to:', autoCopyUnique);
      }
      if (changes.removeHyperlink) {
        removeHyperlink = changes.removeHyperlink.newValue || false;
        console.log('[Smart Text Helper] Remove hyperlink changed to:', removeHyperlink);
      }
      if (changes.enableUSA) {
        enableUSA = changes.enableUSA.newValue !== undefined ? changes.enableUSA.newValue : true;
        console.log('[Smart Text Helper] Enable USA changed to:', enableUSA);
      }
      if (changes.enableEurope) {
        enableEurope = changes.enableEurope.newValue !== undefined ? changes.enableEurope.newValue : true;
        console.log('[Smart Text Helper] Enable Europe changed to:', enableEurope);
      }
    }
  });

  // Remove all popups
  function removePopups(deselectText = false) {
    // Remove by class to catch any duplicates
    const existingPopups = document.querySelectorAll('.smart-text-popup, .smart-text-input');
    existingPopups.forEach(p => {
      if (p.parentNode) {
        p.parentNode.removeChild(p);
      }
    });
    
    if (popup && popup.parentNode) {
      popup.parentNode.removeChild(popup);
    }
    if (inputPopup && inputPopup.parentNode) {
      inputPopup.parentNode.removeChild(inputPopup);
    }
    
    // Deselect text if requested
    if (deselectText) {
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }
    }
    
    popup = null;
    inputPopup = null;
    currentData = null;
    isProcessingSelection = false; // Reset flag when removing popups
  }

  // Get selected text
  function getSelectedText() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      return null;
    }

    const range = selection.getRangeAt(0);
    const text = selection.toString().trim();

    if (!text) {
      return null;
    }

    return {
      text: text,
      range: range,
      selection: selection
    };
  }

  // Normalize text to handle special characters (accents, diacritics) and st./saint variations
  function normalizeText(text) {
    let normalized = text
      .toLowerCase()
      .trim()
      .normalize('NFD') // Decompose combined characters
      .replace(/[\u0300-\u036f]/g, ''); // Remove diacritical marks
    
    // Handle saint/st./st variations
    // Replace "saint " with "st. " for consistency
    normalized = normalized.replace(/^saint\s+/i, 'st. ');
    normalized = normalized.replace(/^st\s+/i, 'st. ');
    
    return normalized;
  }

  // Title case conversion - capitalize first letter of each word
  function toTitleCase(str) {
    return str
      .toLowerCase()
      .split(' ')
      .map(word => {
        // Handle special cases
        if (word === 'st.' || word === 'st') return 'St.';
        if (word === 'saint') return 'Saint';
        // Capitalize first letter of each word
        return word.charAt(0).toUpperCase() + word.slice(1);
      })
      .join(' ');
  }

  // Check if text is a city
  function checkCity(text) {
    if (!text || text.length < 2 || text.length > 50) {
      console.log('[Smart Text Helper] City check failed: invalid length', text);
      return null;
    }

    const normalizedText = normalizeText(text);
    console.log('[Smart Text Helper] Original text:', text, '| Normalized:', normalizedText);
    console.log('[Smart Text Helper] Region settings - USA:', enableUSA, 'Europe:', enableEurope);
    
    let foundCities = [];
    
    // Check custom cities first
    if (customCities && customCities[normalizedText]) {
      const location = customCities[normalizedText];
      console.log('[Smart Text Helper] Found custom city:', normalizedText, 'location:', location);
      foundCities.push({ location: location, isCustom: true });
    }
    
    // Check USA cities ONLY if enableUSA is true
    if (enableUSA && CITY_DATABASE.usa[normalizedText]) {
      const states = CITY_DATABASE.usa[normalizedText];
      console.log('[Smart Text Helper] Found USA city:', normalizedText, 'states:', states);
      states.forEach(state => {
        if (state === 'UK') {
          // UK in USA list means it's in both - handle separately
          foundCities.push({ location: 'UK', isUK: true });
        } else {
          foundCities.push({ location: state, isUSA: true });
        }
      });
    }
    
    // Check European cities ONLY if enableEurope is true
    if (enableEurope && CITY_DATABASE.europe[normalizedText]) {
      const country = CITY_DATABASE.europe[normalizedText];
      console.log('[Smart Text Helper] Found European city:', normalizedText, 'country:', country);
      // Check if we already have this country from USA check
      const hasCountry = foundCities.some(c => c.location === country);
      if (!hasCountry) {
        foundCities.push({ location: country, isEurope: true });
      } else {
        console.log('[Smart Text Helper] Skipping duplicate:', country);
      }
    }
    
    if (foundCities.length === 0) {
      console.log('[Smart Text Helper] Not a city:', normalizedText);
      return null;
    }
    
    // Return merged results with proper title case
    return {
      type: 'city',
      name: toTitleCase(text), // Apply title case to city name
      cities: foundCities
    };
  }

  // Check if selection contains a hyperlink
  function selectionContainsLink(selection) {
    if (!selection || selection.rangeCount === 0) return false;
    
    // Reset links to remove
    linksToRemove = [];
    
    try {
      const range = selection.getRangeAt(0);
      const container = range.commonAncestorContainer;
      
      console.log('[Smart Text Helper] Checking for links in selection');
      console.log('[Smart Text Helper] Container:', container);
      
      // Get the actual element (not text node)
      let element = container.nodeType === Node.TEXT_NODE ? container.parentNode : container;
      
      // Method 1: Check if element itself is a link
      if (element.tagName === 'A') {
        console.log('[Smart Text Helper] Selection element is a link');
        linksToRemove.push(element);
        return true;
      }
      
      // Method 2: Walk up the DOM tree to find parent link
      let currentNode = element;
      let depth = 0;
      while (currentNode && currentNode !== document.body && depth < 10) {
        if (currentNode.tagName === 'A') {
          console.log('[Smart Text Helper] Found parent link at depth', depth);
          linksToRemove.push(currentNode);
          return true;
        }
        currentNode = currentNode.parentNode;
        depth++;
      }
      
      // Method 3: Check if selection contains any <a> tags
      if (element.getElementsByTagName) {
        const links = element.getElementsByTagName('a');
        if (links.length > 0) {
          console.log('[Smart Text Helper] Found', links.length, 'link(s) in container');
          // Store all links
          for (let i = 0; i < links.length; i++) {
            linksToRemove.push(links[i]);
          }
          return true;
        }
      }
      
      // Method 4: Check cloned contents
      const fragment = range.cloneContents();
      if (fragment.querySelectorAll) {
        const links = fragment.querySelectorAll('a');
        if (links.length > 0) {
          console.log('[Smart Text Helper] Found', links.length, 'link(s) in cloned range');
          // We need to find these links in the actual DOM
          const allLinks = document.querySelectorAll('a');
          allLinks.forEach(link => {
            try {
              if (selection.containsNode(link, true)) {
                linksToRemove.push(link);
              }
            } catch (e) {
              // Ignore errors from containsNode
            }
          });
          return linksToRemove.length > 0;
        }
      }
      
      console.log('[Smart Text Helper] No links found in selection');
      return false;
      
    } catch (e) {
      console.error('[Smart Text Helper] Error checking for links:', e);
      return false;
    }
  }

  // Show popup to remove hyperlink
  function showRemoveHyperlinkPopup(range) {
    if (!range) {
      console.error('[Smart Text Helper] No range provided to showRemoveHyperlinkPopup');
      return;
    }

    console.log('[Smart Text Helper] Creating remove hyperlink popup');
    removePopups(false);

    const popup = document.createElement('div');
    popup.className = 'smart-text-popup smart-text-hyperlink-popup';
    
    const title = document.createElement('div');
    title.className = 'smart-text-popup-title';
    title.textContent = 'Remove Hyperlink';
    popup.appendChild(title);

    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'smart-text-popup-buttons';

    const removeButton = document.createElement('button');
    removeButton.className = 'smart-text-popup-button smart-text-convert-button';
    removeButton.textContent = 'Remove Link';
    removeButton.addEventListener('click', () => {
      console.log('[Smart Text Helper] Removing hyperlink');
      const success = removeLinkFromSelection();
      removePopups(true);
      if (success) {
        showNotification('✓ Hyperlink removed');
      } else {
        showNotification('⚠ Could not remove hyperlink');
      }
    });

    const closeButton = document.createElement('button');
    closeButton.className = 'smart-text-popup-button smart-text-close-button';
    closeButton.textContent = 'Close';
    closeButton.addEventListener('click', () => {
      removePopups(true);
    });

    buttonsDiv.appendChild(removeButton);
    buttonsDiv.appendChild(closeButton);
    popup.appendChild(buttonsDiv);

    // Position popup
    const rect = range.getBoundingClientRect();
    document.body.appendChild(popup);
    
    const popupRect = popup.getBoundingClientRect();
    let left = rect.left + window.scrollX + (rect.width / 2) - (popupRect.width / 2);
    let top;

    if (popupPosition === 'top') {
      top = rect.top + window.scrollY - popupRect.height - 10;
    } else if (popupPosition === 'bottom') {
      top = rect.bottom + window.scrollY + 10;
    } else if (popupPosition === 'left') {
      left = rect.left + window.scrollX - popupRect.width - 10;
      top = rect.top + window.scrollY + (rect.height / 2) - (popupRect.height / 2);
    } else if (popupPosition === 'right') {
      left = rect.right + window.scrollX + 10;
      top = rect.top + window.scrollY + (rect.height / 2) - (popupRect.height / 2);
    }

    popup.style.left = `${Math.max(10, left)}px`;
    popup.style.top = `${Math.max(10, top)}px`;

    currentData = null;
    currentRange = range;
  }

  // Remove hyperlink from selection and convert to plain text
  function removeLinkFromSelection() {
    try {
      console.log('[Smart Text Helper] Starting link removal');
      console.log('[Smart Text Helper] Links to remove:', linksToRemove.length);
      
      if (linksToRemove.length === 0) {
        console.warn('[Smart Text Helper] No links stored to remove');
        return false;
      }
      
      let removedCount = 0;
      
      // Remove each stored link
      linksToRemove.forEach((link, index) => {
        try {
          console.log('[Smart Text Helper] Removing link', index + 1, ':', link.textContent);
          
          if (link && link.parentNode) {
            const parent = link.parentNode;
            
            // Create a document fragment to hold the children
            const fragment = document.createDocumentFragment();
            
            // Move all child nodes from the link to the fragment
            // This preserves formatting, nested elements, etc.
            while (link.firstChild) {
              fragment.appendChild(link.firstChild);
            }
            
            // If fragment is empty (shouldn't happen), use text content as fallback
            if (!fragment.hasChildNodes()) {
              const textContent = link.textContent || link.innerText || '';
              fragment.appendChild(document.createTextNode(textContent));
            }
            
            // Replace the link with the fragment
            parent.replaceChild(fragment, link);
            removedCount++;
            console.log('[Smart Text Helper] Successfully removed link');
          } else {
            console.warn('[Smart Text Helper] Link', index + 1, 'has no parent');
          }
        } catch (e) {
          console.error('[Smart Text Helper] Error removing link', index + 1, ':', e);
        }
      });
      
      // Clear the array
      linksToRemove = [];
      
      if (removedCount > 0) {
        console.log('[Smart Text Helper] Successfully removed', removedCount, 'link(s)');
        return true;
      } else {
        console.warn('[Smart Text Helper] Failed to remove any links');
        return false;
      }
      
    } catch (error) {
      console.error('[Smart Text Helper] Error in removeLinkFromSelection:', error);
      linksToRemove = [];
      return false;
    }
  }

  // Detect link type for hyperlinks
  function detectLinkType(text) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailRegex.test(text)) {
      return { type: 'hyperlink', subtype: 'email', href: 'mailto:' + text };
    }

    const phoneRegex = /^[\d\s\-\+\(\)\.]+$/;
    const digitsOnly = text.replace(/\D/g, '');
    if (phoneRegex.test(text) && digitsOnly.length >= 10) {
      return { type: 'hyperlink', subtype: 'phone', href: 'tel:' + digitsOnly };
    }

    const urlRegex = /^(https?:\/\/|www\.)/i;
    if (urlRegex.test(text)) {
      let url = text;
      if (!url.match(/^https?:\/\//i)) {
        url = 'https://' + url;
      }
      return { type: 'hyperlink', subtype: 'url', href: url };
    }

    const domainRegex = /^[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}([\/\?#].*)?$/;
    if (domainRegex.test(text)) {
      return { type: 'hyperlink', subtype: 'url', href: 'https://' + text };
    }

    const searchQuery = encodeURIComponent(text);
    return { type: 'hyperlink', subtype: 'search', href: 'https://www.google.com/search?q=' + searchQuery };
  }

  // Calculate popup position
  function getPopupPosition(range, popupElement) {
    const rects = range.getClientRects();
    if (rects.length === 0) {
      return { x: 0, y: 0 };
    }

    const rect = rects[0];
    const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
    const scrollY = window.pageYOffset || document.documentElement.scrollTop;

    const tempParent = document.body;
    tempParent.appendChild(popupElement);
    const popupRect = popupElement.getBoundingClientRect();
    tempParent.removeChild(popupElement);

    let x, y;

    switch (popupPosition) {
      case 'bottom':
        x = rect.left + scrollX;
        y = rect.bottom + scrollY + 5;
        break;
      case 'left':
        x = rect.left + scrollX - popupRect.width - 10;
        y = rect.top + scrollY;
        break;
      case 'right':
        x = rect.right + scrollX + 10;
        y = rect.top + scrollY;
        break;
      case 'top':
      default:
        x = rect.left + scrollX;
        y = rect.top + scrollY - popupRect.height - 5;
        break;
    }

    const maxX = window.innerWidth + scrollX - popupRect.width - 10;
    const maxY = window.innerHeight + scrollY - popupRect.height - 10;
    
    x = Math.max(10 + scrollX, Math.min(x, maxX));
    y = Math.max(10 + scrollY, Math.min(y, maxY));

    return { x, y };
  }

  // Show notification
  function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'smart-text-notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 2000);
  }

  // Copy individual city
  function copyIndividualCity(cityText) {
    navigator.clipboard.writeText(cityText).then(() => {
      showNotification(`✓ Copied: ${cityText}`);
      removePopups(true); // Close and deselect
    }).catch(err => {
      const textarea = document.createElement('textarea');
      textarea.value = cityText;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showNotification(`✓ Copied: ${cityText}`);
      removePopups(true); // Close and deselect
    });
  }

  // Search city on Google
  function searchCityOnGoogle(cityText) {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(cityText)}`;
    window.open(searchUrl, '_blank');
    showNotification(`🔍 Searching: ${cityText}`);
    removePopups(true); // Close and deselect
  }

  // Show city popup
  function showCityPopup(cityData, range) {
    // Prevent duplicate popups within 500ms
    const now = Date.now();
    if (now - lastPopupTime < 500) {
      console.log('[Smart Text Helper] Preventing duplicate popup (too soon)');
      return;
    }
    lastPopupTime = now;
    
    removePopups();
    currentData = cityData;

    popup = document.createElement('div');
    popup.className = 'smart-text-popup';

    const cityList = document.createElement('ul');
    cityList.className = 'city-list';

    // Handle merged city results
    cityData.cities.forEach(cityInfo => {
      const item = document.createElement('li');
      item.className = 'city-item';
      
      const cityText = document.createElement('span');
      cityText.className = 'city-text';
      const formattedCity = `${cityData.name}, ${cityInfo.location}`;
      cityText.textContent = formattedCity;
      
      const buttonGroup = document.createElement('div');
      buttonGroup.className = 'city-item-buttons';
      
      const copyBtn = document.createElement('button');
      copyBtn.className = 'city-copy-btn';
      copyBtn.textContent = '📋 Copy';
      copyBtn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        copyIndividualCity(formattedCity);
      });
      
      const searchBtn = document.createElement('button');
      searchBtn.className = 'city-search-btn';
      searchBtn.textContent = '🔍 Search';
      searchBtn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        searchCityOnGoogle(formattedCity);
      });
      
      buttonGroup.appendChild(copyBtn);
      buttonGroup.appendChild(searchBtn);
      
      item.appendChild(cityText);
      item.appendChild(buttonGroup);
      cityList.appendChild(item);
    });

    popup.appendChild(cityList);

    const buttonGroup = document.createElement('div');
    buttonGroup.className = 'popup-buttons';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-btn';
    closeBtn.textContent = '✕ Close';
    closeBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      removePopups(true); // Deselect text when closing
    });

    buttonGroup.appendChild(closeBtn);
    popup.appendChild(buttonGroup);

    const position = getPopupPosition(range, popup);
    popup.style.left = position.x + 'px';
    popup.style.top = position.y + 'px';

    document.body.appendChild(popup);
  }

  // Show hyperlink popup
  function showHyperlinkPopup(range) {
    // Prevent duplicate popups within 500ms
    const now = Date.now();
    if (now - lastPopupTime < 500) {
      console.log('[Smart Text Helper] Preventing duplicate popup (too soon)');
      return;
    }
    lastPopupTime = now;
    
    removePopups();

    popup = document.createElement('div');
    popup.className = 'smart-text-popup hyperlink-mode';

    const buttonGroup = document.createElement('div');
    buttonGroup.className = 'popup-buttons';

    const convertBtn = document.createElement('button');
    convertBtn.className = 'convert-btn';
    convertBtn.textContent = '🔗 Convert to Link';
    convertBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showInputPopup(e);
    });

    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-btn';
    closeBtn.textContent = '✕';
    closeBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      removePopups(true); // Deselect text when closing
    });

    buttonGroup.appendChild(convertBtn);
    buttonGroup.appendChild(closeBtn);
    popup.appendChild(buttonGroup);

    const position = getPopupPosition(range, popup);
    popup.style.left = position.x + 'px';
    popup.style.top = position.y + 'px';

    document.body.appendChild(popup);
  }

  // Show input popup for URL
  function showInputPopup(e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (!currentRange) {
      return;
    }

    const selectedText = currentSelection.toString().trim();
    const linkInfo = detectLinkType(selectedText);

    if (linkInfo.subtype === 'email' || linkInfo.subtype === 'phone' || linkInfo.subtype === 'url' || linkInfo.subtype === 'search') {
      createHyperlink(linkInfo.href);
      return;
    }

    const position = getPopupPosition(currentRange, popup);
    removePopups();

    inputPopup = document.createElement('div');
    inputPopup.className = 'smart-text-input';
    inputPopup.style.left = position.x + 'px';
    inputPopup.style.top = position.y + 'px';

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Enter URL';
    input.value = '';

    const buttonGroup = document.createElement('div');
    buttonGroup.className = 'button-group';

    const createBtn = document.createElement('button');
    createBtn.className = 'create-btn';
    createBtn.textContent = 'Create Link';
    createBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      createHyperlink(input.value || '');
    });

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'cancel-btn';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.addEventListener('click', () => removePopups(true)); // Deselect when canceling

    buttonGroup.appendChild(createBtn);
    buttonGroup.appendChild(cancelBtn);

    inputPopup.appendChild(input);
    inputPopup.appendChild(buttonGroup);

    document.body.appendChild(inputPopup);

    const inputRect = inputPopup.getBoundingClientRect();
    if (inputRect.right > window.innerWidth) {
      inputPopup.style.left = (position.x - inputRect.width - 10) + 'px';
    }
    if (inputRect.bottom > window.innerHeight + window.pageYOffset) {
      inputPopup.style.top = (position.y - inputRect.height - 30) + 'px';
    }

    input.focus();

    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        createHyperlink(input.value || '');
      }
    });
  }

  // Create hyperlink
  function createHyperlink(url) {
    if (!currentRange) {
      removePopups();
      return;
    }

    let finalUrl = url.trim();
    
    if (!finalUrl) {
      finalUrl = '';
    } else if (!finalUrl.match(/^(https?:\/\/|mailto:|tel:)/i)) {
      finalUrl = 'https://' + finalUrl;
    }

    try {
      const range = currentRange.cloneRange();
      
      const link = document.createElement('a');
      link.href = finalUrl || '#';
      link.className = 'text-to-link-created';
      link.setAttribute('data-smart-text-helper', 'true'); // Marker for addon-created links
      
      if (finalUrl && !finalUrl.startsWith('mailto:') && !finalUrl.startsWith('tel:')) {
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
      }

      const contents = range.extractContents();
      link.appendChild(contents);
      range.insertNode(link);
      
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }

      let message = '✓ Link created!';
      if (finalUrl.startsWith('mailto:')) {
        message = '✓ Email link created!';
      } else if (finalUrl.startsWith('tel:')) {
        message = '✓ Phone link created!';
      } else if (finalUrl.includes('google.com/search?q=')) {
        message = '✓ Google search link created!';
      } else if (!finalUrl || finalUrl === '#') {
        message = '✓ Link created (no URL)';
      }
      
      showNotification(message);
      
    } catch (error) {
      console.error('[Smart Text Helper] Error creating hyperlink:', error);
      showNotification('✗ Could not create link');
    }

    removePopups();
  }

  // Handle text selection
  function handleSelection() {
    // Prevent processing if already processing
    if (isProcessingSelection) {
      console.log('[Smart Text Helper] Already processing selection, skipping');
      return;
    }
    
    if (selectionTimeout) {
      clearTimeout(selectionTimeout);
    }

    selectionTimeout = setTimeout(() => {
      isProcessingSelection = true;
      
      const selectionData = getSelectedText();
      
      if (!selectionData || selectionData.text.length === 0) {
        removePopups();
        currentSelection = null;
        currentRange = null;
        isProcessingSelection = false;
        return;
      }

      currentSelection = selectionData.selection;
      currentRange = selectionData.range;

      console.log('[Smart Text Helper] Selected text:', selectionData.text);

      // PRIORITY 1: Check if selection contains a hyperlink (if removeHyperlink is enabled)
      // This must be checked FIRST before city detection
      if (removeHyperlink && selectionContainsLink(selectionData.selection)) {
        console.log('[Smart Text Helper] Selection contains hyperlink, showing remove popup');
        showRemoveHyperlinkPopup(selectionData.range);
        return;
      }

      // PRIORITY 2: Check if it's a city
      const cityData = checkCity(selectionData.text);
      
      console.log('[Smart Text Helper] City check result:', cityData);
      
      if (cityData) {
        console.log('[Smart Text Helper] Showing city popup');
        
        const cityCount = cityData.cities.length;
        
        // Auto-copy mode: copy all cities and show notification
        if (autoCopy) {
          console.log('[Smart Text Helper] Auto-copy ALL enabled, copying cities');
          const formattedCities = cityData.cities.map(c => `${cityData.name}, ${c.location}`).join('\n');
          
          navigator.clipboard.writeText(formattedCities).then(() => {
            const message = cityCount > 1 ? 
              `✓ Copied ${cityCount} locations:\n${formattedCities}` : 
              `✓ Copied: ${formattedCities}`;
            showNotification(message);
            // Unselect text after successful copy
            const selection = window.getSelection();
            if (selection) {
              selection.removeAllRanges();
            }
          }).catch(err => {
            // Fallback method
            const textarea = document.createElement('textarea');
            textarea.value = formattedCities;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            const success = document.execCommand('copy');
            document.body.removeChild(textarea);
            
            if (success) {
              const message = cityCount > 1 ? 
                `✓ Copied ${cityCount} locations:\n${formattedCities}` : 
                `✓ Copied: ${formattedCities}`;
              showNotification(message);
              // Unselect text after successful copy
              const selection = window.getSelection();
              if (selection) {
                selection.removeAllRanges();
              }
            }
          });
          isProcessingSelection = false;
        } else if (autoCopyUnique && cityCount === 1) {
          // Auto-copy unique: only copy if there's exactly 1 location
          console.log('[Smart Text Helper] Auto-copy UNIQUE enabled, only 1 location, copying');
          const formattedCity = `${cityData.name}, ${cityData.cities[0].location}`;
          
          // Use a flag to track if copy was successful
          let copySuccessful = false;
          
          navigator.clipboard.writeText(formattedCity).then(() => {
            copySuccessful = true;
            showNotification(`✓ Copied: ${formattedCity}`);
            // Unselect text after successful copy
            const selection = window.getSelection();
            if (selection) {
              selection.removeAllRanges();
            }
          }).catch(err => {
            // Fallback method
            const textarea = document.createElement('textarea');
            textarea.value = formattedCity;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            const success = document.execCommand('copy');
            document.body.removeChild(textarea);
            
            if (success) {
              copySuccessful = true;
              showNotification(`✓ Copied: ${formattedCity}`);
              // Unselect text after successful copy
              const selection = window.getSelection();
              if (selection) {
                selection.removeAllRanges();
              }
            }
          });
          isProcessingSelection = false;
        } else {
          // Normal mode: show popup
          showCityPopup(cityData, selectionData.range);
        }
      } else if (enableHyperlink) {
        console.log('[Smart Text Helper] Showing hyperlink popup');
        // Not a city, show hyperlink options (if enabled)
        showHyperlinkPopup(selectionData.range);
      } else {
        console.log('[Smart Text Helper] Hyperlink feature disabled, not showing popup');
        isProcessingSelection = false;
      }
      
      // Reset flag after popup is shown
      setTimeout(() => {
        isProcessingSelection = false;
      }, 200);
    }, 300); // Increased from 150ms to 300ms - wait for user to finish selecting
  }

  // Handle selection from input and textarea elements
  function handleInputSelection(element) {
    if (!element.value) return;
    
    const selectionStart = element.selectionStart;
    const selectionEnd = element.selectionEnd;
    
    if (selectionStart === selectionEnd) {
      // No text selected
      return;
    }
    
    const selectedText = element.value.substring(selectionStart, selectionEnd).trim();
    console.log('[Smart Text Helper] Input selection:', selectedText);
    
    if (selectedText.length < 2) {
      removePopups();
      return;
    }
    
    // Process the selected text
    processSelectedText(selectedText);
  }
  
  // Process selected text and show popup if needed
  function processSelectedText(text) {
    if (isProcessingSelection) {
      console.log('[Smart Text Helper] Already processing selection, skipping');
      return;
    }
    
    isProcessingSelection = true;
    
    // Clear any existing timeout
    if (selectionTimeout) {
      clearTimeout(selectionTimeout);
    }
    
    selectionTimeout = setTimeout(() => {
      console.log('[Smart Text Helper] Processing text:', text);
      
      // Check for remove hyperlink first
      if (removeHyperlink) {
        const selection = window.getSelection();
        const linksInSelection = selection.rangeCount > 0 ? 
          Array.from(selection.getRangeAt(0).commonAncestorContainer.parentNode?.querySelectorAll('a') || []) : [];
        if (linksInSelection.length > 0) {
          console.log('[Smart Text Helper] Links found in selection');
          linksToRemove = linksInSelection;
          showRemoveHyperlinkPopup(text);
          isProcessingSelection = false;
          return;
        }
      }
      
      // Check for city
      const cityData = checkCity(text);
      if (cityData) {
        console.log('[Smart Text Helper] City found:', cityData);
        
        const cityCount = cityData.cities.length;
        const regionsEnabled = (enableUSA ? 1 : 0) + (enableEurope ? 1 : 0);
        
        // Auto-copy logic for single region with single city
        if (regionsEnabled === 1 && cityCount === 1 && !autoCopy && !autoCopyUnique) {
          const formattedCity = `${cityData.name}, ${cityData.cities[0].location}`;
          navigator.clipboard.writeText(formattedCity).then(() => {
            showNotification(`✓ Copied: ${formattedCity}`);
          }).catch(() => {
            console.error('[Smart Text Helper] Copy failed');
          });
          isProcessingSelection = false;
          return;
        }
        
        // Auto-copy all cities
        if (autoCopy) {
          const formattedCities = cityData.cities.map(c => `${cityData.name}, ${c.location}`).join('\n');
          navigator.clipboard.writeText(formattedCities).then(() => {
            showNotification(`✓ Copied ${cityCount} cities`);
          }).catch(() => {
            console.error('[Smart Text Helper] Copy failed');
          });
          isProcessingSelection = false;
          return;
        }
        
        // Auto-copy unique (only 1 city)
        if (autoCopyUnique && cityCount === 1) {
          const formattedCity = `${cityData.name}, ${cityData.cities[0].location}`;
          navigator.clipboard.writeText(formattedCity).then(() => {
            showNotification(`✓ Copied: ${formattedCity}`);
          }).catch(() => {
            console.error('[Smart Text Helper] Copy failed');
          });
          isProcessingSelection = false;
          return;
        }
        
        // Show popup
        showCityPopup(cityData);
        isProcessingSelection = false;
        return;
      }
      
      // Check for hyperlink conversion
      if (enableHyperlink) {
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          if (range.commonAncestorContainer.parentNode?.tagName === 'A') {
            // Already a link, skip
            isProcessingSelection = false;
            return;
          }
        }
        
        console.log('[Smart Text Helper] No city found, checking for hyperlink conversion');
        showConvertToLinkPopup(text);
      }
      
      isProcessingSelection = false;
    }, 300);
  }

  // Event listeners
  document.addEventListener('mouseup', handleSelection);
  document.addEventListener('keyup', (e) => {
    if (e.shiftKey || e.key === 'Shift') {
      handleSelection();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.key === 'Esc') {
      removePopups();
    }
  });

  // Support for input and textarea elements
  document.addEventListener('mouseup', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
      handleInputSelection(e.target);
    }
  });

  document.addEventListener('keyup', (e) => {
    if ((e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') && (e.shiftKey || e.key === 'Shift')) {
      handleInputSelection(e.target);
    }
  });

  // Support Ctrl+A in input/textarea
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        // Allow Ctrl+A to work normally, will be processed on keyup
      }
    }
  });

  document.addEventListener('mousedown', (e) => {
    if (popup && !popup.contains(e.target) && (!inputPopup || !inputPopup.contains(e.target))) {
      removePopups();
    } else if (inputPopup && !inputPopup.contains(e.target)) {
      removePopups();
    }
  });

  document.addEventListener('selectstart', (e) => {
    return true;
  }, true);

  document.addEventListener('copy', (e) => {
    return true;
  }, true);

  // Listen for hotkey command
  if (typeof browser !== 'undefined' && browser.commands) {
    browser.commands.onCommand.addListener((command) => {
      if (command === 'toggle-region') {
        toggleRegionMode();
      }
    });
  }
  
  // Toggle region mode function
  function toggleRegionMode() {
    // Cycle: Both -> USA Only -> Europe Only -> Both
    if (enableUSA && enableEurope) {
      // Currently both enabled -> Switch to USA only
      enableEurope = false;
      enableUSA = true;
      storage.set({enableUSA: true, enableEurope: false});
      showNotification('🇺🇸 USA Mode Only');
    } else if (enableUSA && !enableEurope) {
      // Currently USA only -> Switch to Europe only
      enableUSA = false;
      enableEurope = true;
      storage.set({enableUSA: false, enableEurope: true});
      showNotification('🇪🇺 Europe Mode Only');
    } else {
      // Currently Europe only (or neither) -> Switch to both
      enableUSA = true;
      enableEurope = true;
      storage.set({enableUSA: true, enableEurope: true});
      showNotification('🌍 Both Regions Enabled');
    }
    console.log('[Smart Text Helper] Region mode toggled - USA:', enableUSA, 'Europe:', enableEurope);
  }

  console.log('[Smart Text Helper] Extension loaded - City detection and hyperlink conversion enabled');

})();
