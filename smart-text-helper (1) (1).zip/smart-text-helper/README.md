# Smart Text Helper - Firefox Addon

A powerful Firefox addon that combines two essential features: automatic city name formatting and intelligent text-to-hyperlink conversion. Select any text and get smart suggestions based on what you've selected.

## 🌟 Features

### 1. City Name Detection & Formatting
- **USA Cities**: Displays as "City Name, State" (e.g., Boston, MA)
- **UK Cities**: Displays as "City Name, UK" (e.g., London, UK)
- **European Cities**: Displays as "City Name, Country" (e.g., Paris, France, Poznan, Poland, Sarajevo, Bosnia and Herzegovina)
- **Individual Copy Buttons**: Each city has its own copy button
- **Handles Duplicates**: Cities with same names in different states/countries show all options
- **Comprehensive Coverage**: 1000+ US cities, 400+ European cities

### 2. Text to Hyperlink Conversion
- **Auto-Detection**: Automatically detects email, phone, URL, or regular text
- **Email → mailto: links**: Select "user@example.com" → Creates mailto link
- **Phone → tel: links**: Select phone numbers → Creates clickable call link
- **URLs → Direct links**: Select "google.com" → Creates https link
- **Text → Google Search**: Select "Amy Johnson" → Creates Google search link
- **Hyperlink Styling**: Created links appear blue and underlined like normal links

### 3. Smart Behavior
- **City Priority**: If selected text is a city, shows city popup
- **Hyperlink Fallback**: If not a city, shows hyperlink conversion options
- **No Conflicts**: Both features work seamlessly together
- **Instant Feedback**: Top-right notifications show what was copied/created
- **Auto-Close**: Popup closes immediately after copying or creating link

## 📋 Supported Locations

### United States (1000+ cities)
- All 50 states + DC, Puerto Rico, and territories
- Includes: Poway, CA; Kansas City (KS & MO); Springfield (5 states); Portland (OR & ME)
- Major cities, medium cities, and many small cities

### Europe (400+ cities)
**Comprehensive coverage including:**
- **UK**: London, Manchester, Birmingham, etc.
- **Poland**: Warsaw, Krakow, **Poznan**, Gdansk, Wroclaw, etc.
- **Balkans**: **Sarajevo**, Belgrade, Zagreb, Ljubljana, Skopje, Tirana, etc.
- **France**: Paris, Marseille, Lyon, Toulouse, etc.
- **Germany**: Berlin, Munich, Hamburg, Frankfurt, etc.
- **Spain**: Madrid, Barcelona, Valencia, Seville, etc.
- **Italy**: Rome, Milan, Naples, Florence, etc.
- **Romania**: Bucharest, Cluj-Napoca, Timisoara, Iasi, etc.
- **And many more**: Bulgaria, Czech Republic, Slovakia, Hungary, Greece, Portugal, Austria, Belgium, Switzerland, Scandinavia, Ireland, Baltic States, Ukraine, Belarus, Moldova

## 🚀 Installation

### Temporary Installation (Testing)
1. Open Firefox → `about:debugging`
2. Click "This Firefox"
3. Click "Load Temporary Add-on"
4. Select `manifest.json` from the addon folder
5. Active until Firefox restarts

### Permanent Installation
1. Create ZIP of all addon files
2. Firefox → `about:addons`
3. Gear icon → "Install Add-on From File"
4. Select ZIP file
5. Confirm installation

## 💡 Usage Examples

### City Detection
1. Select "Poznan" → Shows: "Poznan, Poland" [📋 Copy]
2. Select "Kansas City" → Shows:
   - Kansas City, KS [📋 Copy]
   - Kansas City, MO [📋 Copy]
3. Select "Sarajevo" → Shows: "Sarajevo, Bosnia and Herzegovina" [📋 Copy]
4. Click copy button → Popup closes, notification shows "✓ Copied: Poznan, Poland"

### Hyperlink Conversion
1. Select "contact@example.com" → Auto-converts to mailto: link
2. Select "555-1234" → Auto-converts to tel: link
3. Select "wikipedia.org" → Auto-converts to https://wikipedia.org
4. Select "Marie Curie" → Auto-converts to Google search link
5. Notification shows "✓ Email link created!" or "✓ Google search link created!"

## ⚙️ Settings

Access via: `about:addons` → Smart Text Helper → Preferences

**Popup Position:**
- **Top** (default): Above selected text
- **Bottom**: Below selected text
- **Left**: To the left of selected text
- **Right**: To the right of selected text

## 🎯 Key Improvements

✅ **Fixed duplicate popup issue** - Now shows only once
✅ **Individual copy buttons** - Each city row has its own copy
✅ **Immediate popup close** - Closes right after copying
✅ **Top-right notifications** - Shows what was copied/created
✅ **Both features work together** - No conflicts between city detection and hyperlink conversion
✅ **ALL European cities** - Including Poznan, Sarajevo, and hundreds more
✅ **Blue hyperlink styling** - Created links look like real links

## 🔧 Technical Details

- **Optimized Performance**: Debounced selection (100ms), O(1) city lookup
- **Low CPU Usage**: Efficient event handling, minimal DOM operations
- **No Data Collection**: Works entirely locally
- **No External Servers**: All processing in-browser
- **Conflict-Free**: Smart detection prevents feature conflicts

## 🐛 Troubleshooting

**Popup doesn't appear:**
- Ensure addon is enabled in `about:addons`
- Try refreshing the page
- Check that you're selecting valid text

**City not recognized:**
- Only major cities are included
- Check spelling

**Hyperlink not created:**
- Try selecting the text again
- Make sure popup appeared before clicking away

## 📝 File Structure

```
smart-text-helper/
├── manifest.json          # Addon configuration
├── content.js            # Main functionality (merged)
├── cities-data.js        # Comprehensive city database
├── popup.css             # Styling for both features
├── settings.html         # Settings page UI
├── settings.js           # Settings functionality
├── icon.png              # Addon icon
└── README.md             # This file
```

## 🔐 Privacy

- ✅ Works entirely locally
- ✅ NO data collection
- ✅ NO external servers
- ✅ NO tracking
- ✅ Only activates on text selection

## 📜 License

Free to use and modify for personal and commercial purposes.

---

**Smart Text Helper - Making text selection smarter!** 🚀
